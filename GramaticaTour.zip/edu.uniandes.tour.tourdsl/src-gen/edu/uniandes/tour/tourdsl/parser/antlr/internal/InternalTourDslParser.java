package edu.uniandes.tour.tourdsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import edu.uniandes.tour.tourdsl.services.TourDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalTourDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_LBRACKET", "RULE_NAME", "RULE_TWOPOINTS", "RULE_COMA", "RULE_PLACES", "RULE_LPARENTISISCUADRADO", "RULE_RPARENTISISCUADRADO", "RULE_RBRACKET", "RULE_DESCRIPTION", "RULE_STRING", "RULE_PATHS", "RULE_TO", "RULE_ROTATION", "RULE_ROTX", "RULE_ROTY", "RULE_ROTZ", "RULE_POSITION", "RULE_POSX", "RULE_POSY", "RULE_POSZ", "RULE_INT", "RULE_EQUALS", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER"
    };
    public static final int RULE_LBRACKET=4;
    public static final int RULE_COMA=7;
    public static final int RULE_PATHS=14;
    public static final int RULE_TO=15;
    public static final int RULE_NAME=5;
    public static final int RULE_PLACES=8;
    public static final int RULE_STRING=13;
    public static final int RULE_ROTX=17;
    public static final int RULE_ROTY=18;
    public static final int RULE_ROTZ=19;
    public static final int RULE_POSITION=20;
    public static final int RULE_SL_COMMENT=28;
    public static final int RULE_RPARENTISISCUADRADO=10;
    public static final int RULE_EQUALS=25;
    public static final int RULE_LPARENTISISCUADRADO=9;
    public static final int EOF=-1;
    public static final int RULE_POSX=21;
    public static final int RULE_ID=26;
    public static final int RULE_WS=29;
    public static final int RULE_DESCRIPTION=12;
    public static final int RULE_ROTATION=16;
    public static final int RULE_ANY_OTHER=30;
    public static final int RULE_POSZ=23;
    public static final int RULE_POSY=22;
    public static final int RULE_INT=24;
    public static final int RULE_TWOPOINTS=6;
    public static final int RULE_ML_COMMENT=27;
    public static final int RULE_RBRACKET=11;

    // delegates
    // delegators


        public InternalTourDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalTourDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalTourDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalTourDsl.g"; }



     	private TourDslGrammarAccess grammarAccess;

        public InternalTourDslParser(TokenStream input, TourDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Tour";
       	}

       	@Override
       	protected TourDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleTour"
    // InternalTourDsl.g:64:1: entryRuleTour returns [EObject current=null] : iv_ruleTour= ruleTour EOF ;
    public final EObject entryRuleTour() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTour = null;


        try {
            // InternalTourDsl.g:64:45: (iv_ruleTour= ruleTour EOF )
            // InternalTourDsl.g:65:2: iv_ruleTour= ruleTour EOF
            {
             newCompositeNode(grammarAccess.getTourRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTour=ruleTour();

            state._fsp--;

             current =iv_ruleTour; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTour"


    // $ANTLR start "ruleTour"
    // InternalTourDsl.g:71:1: ruleTour returns [EObject current=null] : ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_PLACES_6= RULE_PLACES this_TWOPOINTS_7= RULE_TWOPOINTS this_LPARENTISISCUADRADO_8= RULE_LPARENTISISCUADRADO ( (lv_panorama_9_0= rulePanorama ) )+ this_RPARENTISISCUADRADO_10= RULE_RPARENTISISCUADRADO this_RBRACKET_11= RULE_RBRACKET ) ;
    public final EObject ruleTour() throws RecognitionException {
        EObject current = null;

        Token this_LBRACKET_1=null;
        Token this_NAME_2=null;
        Token this_TWOPOINTS_3=null;
        Token this_COMA_5=null;
        Token this_PLACES_6=null;
        Token this_TWOPOINTS_7=null;
        Token this_LPARENTISISCUADRADO_8=null;
        Token this_RPARENTISISCUADRADO_10=null;
        Token this_RBRACKET_11=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        EObject lv_panorama_9_0 = null;



        	enterRule();

        try {
            // InternalTourDsl.g:77:2: ( ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_PLACES_6= RULE_PLACES this_TWOPOINTS_7= RULE_TWOPOINTS this_LPARENTISISCUADRADO_8= RULE_LPARENTISISCUADRADO ( (lv_panorama_9_0= rulePanorama ) )+ this_RPARENTISISCUADRADO_10= RULE_RPARENTISISCUADRADO this_RBRACKET_11= RULE_RBRACKET ) )
            // InternalTourDsl.g:78:2: ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_PLACES_6= RULE_PLACES this_TWOPOINTS_7= RULE_TWOPOINTS this_LPARENTISISCUADRADO_8= RULE_LPARENTISISCUADRADO ( (lv_panorama_9_0= rulePanorama ) )+ this_RPARENTISISCUADRADO_10= RULE_RPARENTISISCUADRADO this_RBRACKET_11= RULE_RBRACKET )
            {
            // InternalTourDsl.g:78:2: ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_PLACES_6= RULE_PLACES this_TWOPOINTS_7= RULE_TWOPOINTS this_LPARENTISISCUADRADO_8= RULE_LPARENTISISCUADRADO ( (lv_panorama_9_0= rulePanorama ) )+ this_RPARENTISISCUADRADO_10= RULE_RPARENTISISCUADRADO this_RBRACKET_11= RULE_RBRACKET )
            // InternalTourDsl.g:79:3: () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_PLACES_6= RULE_PLACES this_TWOPOINTS_7= RULE_TWOPOINTS this_LPARENTISISCUADRADO_8= RULE_LPARENTISISCUADRADO ( (lv_panorama_9_0= rulePanorama ) )+ this_RPARENTISISCUADRADO_10= RULE_RPARENTISISCUADRADO this_RBRACKET_11= RULE_RBRACKET
            {
            // InternalTourDsl.g:79:3: ()
            // InternalTourDsl.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTourAccess().getTourAction_0(),
            					current);
            			

            }

            this_LBRACKET_1=(Token)match(input,RULE_LBRACKET,FOLLOW_3); 

            			newLeafNode(this_LBRACKET_1, grammarAccess.getTourAccess().getLBRACKETTerminalRuleCall_1());
            		
            this_NAME_2=(Token)match(input,RULE_NAME,FOLLOW_4); 

            			newLeafNode(this_NAME_2, grammarAccess.getTourAccess().getNAMETerminalRuleCall_2());
            		
            this_TWOPOINTS_3=(Token)match(input,RULE_TWOPOINTS,FOLLOW_5); 

            			newLeafNode(this_TWOPOINTS_3, grammarAccess.getTourAccess().getTWOPOINTSTerminalRuleCall_3());
            		
            // InternalTourDsl.g:98:3: ( (lv_nombre_4_0= ruleEString ) )
            // InternalTourDsl.g:99:4: (lv_nombre_4_0= ruleEString )
            {
            // InternalTourDsl.g:99:4: (lv_nombre_4_0= ruleEString )
            // InternalTourDsl.g:100:5: lv_nombre_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getTourAccess().getNombreEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_6);
            lv_nombre_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTourRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_4_0,
            						"edu.uniandes.tour.tourdsl.TourDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_COMA_5=(Token)match(input,RULE_COMA,FOLLOW_7); 

            			newLeafNode(this_COMA_5, grammarAccess.getTourAccess().getCOMATerminalRuleCall_5());
            		
            this_PLACES_6=(Token)match(input,RULE_PLACES,FOLLOW_4); 

            			newLeafNode(this_PLACES_6, grammarAccess.getTourAccess().getPLACESTerminalRuleCall_6());
            		
            this_TWOPOINTS_7=(Token)match(input,RULE_TWOPOINTS,FOLLOW_8); 

            			newLeafNode(this_TWOPOINTS_7, grammarAccess.getTourAccess().getTWOPOINTSTerminalRuleCall_7());
            		
            this_LPARENTISISCUADRADO_8=(Token)match(input,RULE_LPARENTISISCUADRADO,FOLLOW_9); 

            			newLeafNode(this_LPARENTISISCUADRADO_8, grammarAccess.getTourAccess().getLPARENTISISCUADRADOTerminalRuleCall_8());
            		
            // InternalTourDsl.g:133:3: ( (lv_panorama_9_0= rulePanorama ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==RULE_LBRACKET) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalTourDsl.g:134:4: (lv_panorama_9_0= rulePanorama )
            	    {
            	    // InternalTourDsl.g:134:4: (lv_panorama_9_0= rulePanorama )
            	    // InternalTourDsl.g:135:5: lv_panorama_9_0= rulePanorama
            	    {

            	    					newCompositeNode(grammarAccess.getTourAccess().getPanoramaPanoramaParserRuleCall_9_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_panorama_9_0=rulePanorama();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTourRule());
            	    					}
            	    					add(
            	    						current,
            	    						"panorama",
            	    						lv_panorama_9_0,
            	    						"edu.uniandes.tour.tourdsl.TourDsl.Panorama");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            this_RPARENTISISCUADRADO_10=(Token)match(input,RULE_RPARENTISISCUADRADO,FOLLOW_11); 

            			newLeafNode(this_RPARENTISISCUADRADO_10, grammarAccess.getTourAccess().getRPARENTISISCUADRADOTerminalRuleCall_10());
            		
            this_RBRACKET_11=(Token)match(input,RULE_RBRACKET,FOLLOW_2); 

            			newLeafNode(this_RBRACKET_11, grammarAccess.getTourAccess().getRBRACKETTerminalRuleCall_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTour"


    // $ANTLR start "entryRulePanorama"
    // InternalTourDsl.g:164:1: entryRulePanorama returns [EObject current=null] : iv_rulePanorama= rulePanorama EOF ;
    public final EObject entryRulePanorama() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePanorama = null;


        try {
            // InternalTourDsl.g:164:49: (iv_rulePanorama= rulePanorama EOF )
            // InternalTourDsl.g:165:2: iv_rulePanorama= rulePanorama EOF
            {
             newCompositeNode(grammarAccess.getPanoramaRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePanorama=rulePanorama();

            state._fsp--;

             current =iv_rulePanorama; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePanorama"


    // $ANTLR start "rulePanorama"
    // InternalTourDsl.g:171:1: rulePanorama returns [EObject current=null] : ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_DESCRIPTION_6= RULE_DESCRIPTION this_TWOPOINTS_7= RULE_TWOPOINTS ( (lv_nombre_8_0= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_rotacionPanorama_10_0= ruleRotacionPanorama ) ) this_COMA_11= RULE_COMA this_PATHS_12= RULE_PATHS this_TWOPOINTS_13= RULE_TWOPOINTS this_LPARENTISISCUADRADO_14= RULE_LPARENTISISCUADRADO ( (lv_hotspot_15_0= ruleHotspot ) )+ (this_COMA_16= RULE_COMA )? this_RPARENTISISCUADRADO_17= RULE_RPARENTISISCUADRADO this_RBRACKET_18= RULE_RBRACKET ) ;
    public final EObject rulePanorama() throws RecognitionException {
        EObject current = null;

        Token this_LBRACKET_1=null;
        Token this_NAME_2=null;
        Token this_TWOPOINTS_3=null;
        Token this_COMA_5=null;
        Token this_DESCRIPTION_6=null;
        Token this_TWOPOINTS_7=null;
        Token lv_nombre_8_0=null;
        Token this_COMA_9=null;
        Token this_COMA_11=null;
        Token this_PATHS_12=null;
        Token this_TWOPOINTS_13=null;
        Token this_LPARENTISISCUADRADO_14=null;
        Token this_COMA_16=null;
        Token this_RPARENTISISCUADRADO_17=null;
        Token this_RBRACKET_18=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        EObject lv_rotacionPanorama_10_0 = null;

        EObject lv_hotspot_15_0 = null;



        	enterRule();

        try {
            // InternalTourDsl.g:177:2: ( ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_DESCRIPTION_6= RULE_DESCRIPTION this_TWOPOINTS_7= RULE_TWOPOINTS ( (lv_nombre_8_0= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_rotacionPanorama_10_0= ruleRotacionPanorama ) ) this_COMA_11= RULE_COMA this_PATHS_12= RULE_PATHS this_TWOPOINTS_13= RULE_TWOPOINTS this_LPARENTISISCUADRADO_14= RULE_LPARENTISISCUADRADO ( (lv_hotspot_15_0= ruleHotspot ) )+ (this_COMA_16= RULE_COMA )? this_RPARENTISISCUADRADO_17= RULE_RPARENTISISCUADRADO this_RBRACKET_18= RULE_RBRACKET ) )
            // InternalTourDsl.g:178:2: ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_DESCRIPTION_6= RULE_DESCRIPTION this_TWOPOINTS_7= RULE_TWOPOINTS ( (lv_nombre_8_0= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_rotacionPanorama_10_0= ruleRotacionPanorama ) ) this_COMA_11= RULE_COMA this_PATHS_12= RULE_PATHS this_TWOPOINTS_13= RULE_TWOPOINTS this_LPARENTISISCUADRADO_14= RULE_LPARENTISISCUADRADO ( (lv_hotspot_15_0= ruleHotspot ) )+ (this_COMA_16= RULE_COMA )? this_RPARENTISISCUADRADO_17= RULE_RPARENTISISCUADRADO this_RBRACKET_18= RULE_RBRACKET )
            {
            // InternalTourDsl.g:178:2: ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_DESCRIPTION_6= RULE_DESCRIPTION this_TWOPOINTS_7= RULE_TWOPOINTS ( (lv_nombre_8_0= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_rotacionPanorama_10_0= ruleRotacionPanorama ) ) this_COMA_11= RULE_COMA this_PATHS_12= RULE_PATHS this_TWOPOINTS_13= RULE_TWOPOINTS this_LPARENTISISCUADRADO_14= RULE_LPARENTISISCUADRADO ( (lv_hotspot_15_0= ruleHotspot ) )+ (this_COMA_16= RULE_COMA )? this_RPARENTISISCUADRADO_17= RULE_RPARENTISISCUADRADO this_RBRACKET_18= RULE_RBRACKET )
            // InternalTourDsl.g:179:3: () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_DESCRIPTION_6= RULE_DESCRIPTION this_TWOPOINTS_7= RULE_TWOPOINTS ( (lv_nombre_8_0= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_rotacionPanorama_10_0= ruleRotacionPanorama ) ) this_COMA_11= RULE_COMA this_PATHS_12= RULE_PATHS this_TWOPOINTS_13= RULE_TWOPOINTS this_LPARENTISISCUADRADO_14= RULE_LPARENTISISCUADRADO ( (lv_hotspot_15_0= ruleHotspot ) )+ (this_COMA_16= RULE_COMA )? this_RPARENTISISCUADRADO_17= RULE_RPARENTISISCUADRADO this_RBRACKET_18= RULE_RBRACKET
            {
            // InternalTourDsl.g:179:3: ()
            // InternalTourDsl.g:180:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPanoramaAccess().getPanoramaAction_0(),
            					current);
            			

            }

            this_LBRACKET_1=(Token)match(input,RULE_LBRACKET,FOLLOW_3); 

            			newLeafNode(this_LBRACKET_1, grammarAccess.getPanoramaAccess().getLBRACKETTerminalRuleCall_1());
            		
            this_NAME_2=(Token)match(input,RULE_NAME,FOLLOW_4); 

            			newLeafNode(this_NAME_2, grammarAccess.getPanoramaAccess().getNAMETerminalRuleCall_2());
            		
            this_TWOPOINTS_3=(Token)match(input,RULE_TWOPOINTS,FOLLOW_5); 

            			newLeafNode(this_TWOPOINTS_3, grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_3());
            		
            // InternalTourDsl.g:198:3: ( (lv_nombre_4_0= ruleEString ) )
            // InternalTourDsl.g:199:4: (lv_nombre_4_0= ruleEString )
            {
            // InternalTourDsl.g:199:4: (lv_nombre_4_0= ruleEString )
            // InternalTourDsl.g:200:5: lv_nombre_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getPanoramaAccess().getNombreEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_6);
            lv_nombre_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPanoramaRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_4_0,
            						"edu.uniandes.tour.tourdsl.TourDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_COMA_5=(Token)match(input,RULE_COMA,FOLLOW_12); 

            			newLeafNode(this_COMA_5, grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_5());
            		
            this_DESCRIPTION_6=(Token)match(input,RULE_DESCRIPTION,FOLLOW_4); 

            			newLeafNode(this_DESCRIPTION_6, grammarAccess.getPanoramaAccess().getDESCRIPTIONTerminalRuleCall_6());
            		
            this_TWOPOINTS_7=(Token)match(input,RULE_TWOPOINTS,FOLLOW_5); 

            			newLeafNode(this_TWOPOINTS_7, grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_7());
            		
            // InternalTourDsl.g:229:3: ( (lv_nombre_8_0= RULE_STRING ) )
            // InternalTourDsl.g:230:4: (lv_nombre_8_0= RULE_STRING )
            {
            // InternalTourDsl.g:230:4: (lv_nombre_8_0= RULE_STRING )
            // InternalTourDsl.g:231:5: lv_nombre_8_0= RULE_STRING
            {
            lv_nombre_8_0=(Token)match(input,RULE_STRING,FOLLOW_6); 

            					newLeafNode(lv_nombre_8_0, grammarAccess.getPanoramaAccess().getNombreSTRINGTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPanoramaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nombre",
            						lv_nombre_8_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_COMA_9=(Token)match(input,RULE_COMA,FOLLOW_13); 

            			newLeafNode(this_COMA_9, grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_9());
            		
            // InternalTourDsl.g:251:3: ( (lv_rotacionPanorama_10_0= ruleRotacionPanorama ) )
            // InternalTourDsl.g:252:4: (lv_rotacionPanorama_10_0= ruleRotacionPanorama )
            {
            // InternalTourDsl.g:252:4: (lv_rotacionPanorama_10_0= ruleRotacionPanorama )
            // InternalTourDsl.g:253:5: lv_rotacionPanorama_10_0= ruleRotacionPanorama
            {

            					newCompositeNode(grammarAccess.getPanoramaAccess().getRotacionPanoramaRotacionPanoramaParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_6);
            lv_rotacionPanorama_10_0=ruleRotacionPanorama();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPanoramaRule());
            					}
            					set(
            						current,
            						"rotacionPanorama",
            						lv_rotacionPanorama_10_0,
            						"edu.uniandes.tour.tourdsl.TourDsl.RotacionPanorama");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_COMA_11=(Token)match(input,RULE_COMA,FOLLOW_14); 

            			newLeafNode(this_COMA_11, grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_11());
            		
            this_PATHS_12=(Token)match(input,RULE_PATHS,FOLLOW_4); 

            			newLeafNode(this_PATHS_12, grammarAccess.getPanoramaAccess().getPATHSTerminalRuleCall_12());
            		
            this_TWOPOINTS_13=(Token)match(input,RULE_TWOPOINTS,FOLLOW_8); 

            			newLeafNode(this_TWOPOINTS_13, grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_13());
            		
            this_LPARENTISISCUADRADO_14=(Token)match(input,RULE_LPARENTISISCUADRADO,FOLLOW_9); 

            			newLeafNode(this_LPARENTISISCUADRADO_14, grammarAccess.getPanoramaAccess().getLPARENTISISCUADRADOTerminalRuleCall_14());
            		
            // InternalTourDsl.g:286:3: ( (lv_hotspot_15_0= ruleHotspot ) )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_LBRACKET) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalTourDsl.g:287:4: (lv_hotspot_15_0= ruleHotspot )
            	    {
            	    // InternalTourDsl.g:287:4: (lv_hotspot_15_0= ruleHotspot )
            	    // InternalTourDsl.g:288:5: lv_hotspot_15_0= ruleHotspot
            	    {

            	    					newCompositeNode(grammarAccess.getPanoramaAccess().getHotspotHotspotParserRuleCall_15_0());
            	    				
            	    pushFollow(FOLLOW_15);
            	    lv_hotspot_15_0=ruleHotspot();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getPanoramaRule());
            	    					}
            	    					add(
            	    						current,
            	    						"hotspot",
            	    						lv_hotspot_15_0,
            	    						"edu.uniandes.tour.tourdsl.TourDsl.Hotspot");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            // InternalTourDsl.g:305:3: (this_COMA_16= RULE_COMA )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_COMA) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalTourDsl.g:306:4: this_COMA_16= RULE_COMA
                    {
                    this_COMA_16=(Token)match(input,RULE_COMA,FOLLOW_16); 

                    				newLeafNode(this_COMA_16, grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_16());
                    			

                    }
                    break;

            }

            this_RPARENTISISCUADRADO_17=(Token)match(input,RULE_RPARENTISISCUADRADO,FOLLOW_11); 

            			newLeafNode(this_RPARENTISISCUADRADO_17, grammarAccess.getPanoramaAccess().getRPARENTISISCUADRADOTerminalRuleCall_17());
            		
            this_RBRACKET_18=(Token)match(input,RULE_RBRACKET,FOLLOW_2); 

            			newLeafNode(this_RBRACKET_18, grammarAccess.getPanoramaAccess().getRBRACKETTerminalRuleCall_18());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePanorama"


    // $ANTLR start "entryRuleHotspot"
    // InternalTourDsl.g:323:1: entryRuleHotspot returns [EObject current=null] : iv_ruleHotspot= ruleHotspot EOF ;
    public final EObject entryRuleHotspot() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHotspot = null;


        try {
            // InternalTourDsl.g:323:48: (iv_ruleHotspot= ruleHotspot EOF )
            // InternalTourDsl.g:324:2: iv_ruleHotspot= ruleHotspot EOF
            {
             newCompositeNode(grammarAccess.getHotspotRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHotspot=ruleHotspot();

            state._fsp--;

             current =iv_ruleHotspot; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHotspot"


    // $ANTLR start "ruleHotspot"
    // InternalTourDsl.g:330:1: ruleHotspot returns [EObject current=null] : ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_TO_6= RULE_TO this_TWOPOINTS_7= RULE_TWOPOINTS ( (otherlv_8= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_posicion_10_0= rulePosicion ) ) this_COMA_11= RULE_COMA ( (lv_rotacion_12_0= ruleRotacion ) ) this_RBRACKET_13= RULE_RBRACKET ) ;
    public final EObject ruleHotspot() throws RecognitionException {
        EObject current = null;

        Token this_LBRACKET_1=null;
        Token this_NAME_2=null;
        Token this_TWOPOINTS_3=null;
        Token this_COMA_5=null;
        Token this_TO_6=null;
        Token this_TWOPOINTS_7=null;
        Token otherlv_8=null;
        Token this_COMA_9=null;
        Token this_COMA_11=null;
        Token this_RBRACKET_13=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        EObject lv_posicion_10_0 = null;

        EObject lv_rotacion_12_0 = null;



        	enterRule();

        try {
            // InternalTourDsl.g:336:2: ( ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_TO_6= RULE_TO this_TWOPOINTS_7= RULE_TWOPOINTS ( (otherlv_8= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_posicion_10_0= rulePosicion ) ) this_COMA_11= RULE_COMA ( (lv_rotacion_12_0= ruleRotacion ) ) this_RBRACKET_13= RULE_RBRACKET ) )
            // InternalTourDsl.g:337:2: ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_TO_6= RULE_TO this_TWOPOINTS_7= RULE_TWOPOINTS ( (otherlv_8= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_posicion_10_0= rulePosicion ) ) this_COMA_11= RULE_COMA ( (lv_rotacion_12_0= ruleRotacion ) ) this_RBRACKET_13= RULE_RBRACKET )
            {
            // InternalTourDsl.g:337:2: ( () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_TO_6= RULE_TO this_TWOPOINTS_7= RULE_TWOPOINTS ( (otherlv_8= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_posicion_10_0= rulePosicion ) ) this_COMA_11= RULE_COMA ( (lv_rotacion_12_0= ruleRotacion ) ) this_RBRACKET_13= RULE_RBRACKET )
            // InternalTourDsl.g:338:3: () this_LBRACKET_1= RULE_LBRACKET this_NAME_2= RULE_NAME this_TWOPOINTS_3= RULE_TWOPOINTS ( (lv_nombre_4_0= ruleEString ) ) this_COMA_5= RULE_COMA this_TO_6= RULE_TO this_TWOPOINTS_7= RULE_TWOPOINTS ( (otherlv_8= RULE_STRING ) ) this_COMA_9= RULE_COMA ( (lv_posicion_10_0= rulePosicion ) ) this_COMA_11= RULE_COMA ( (lv_rotacion_12_0= ruleRotacion ) ) this_RBRACKET_13= RULE_RBRACKET
            {
            // InternalTourDsl.g:338:3: ()
            // InternalTourDsl.g:339:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getHotspotAccess().getHotspotAction_0(),
            					current);
            			

            }

            this_LBRACKET_1=(Token)match(input,RULE_LBRACKET,FOLLOW_3); 

            			newLeafNode(this_LBRACKET_1, grammarAccess.getHotspotAccess().getLBRACKETTerminalRuleCall_1());
            		
            this_NAME_2=(Token)match(input,RULE_NAME,FOLLOW_4); 

            			newLeafNode(this_NAME_2, grammarAccess.getHotspotAccess().getNAMETerminalRuleCall_2());
            		
            this_TWOPOINTS_3=(Token)match(input,RULE_TWOPOINTS,FOLLOW_5); 

            			newLeafNode(this_TWOPOINTS_3, grammarAccess.getHotspotAccess().getTWOPOINTSTerminalRuleCall_3());
            		
            // InternalTourDsl.g:357:3: ( (lv_nombre_4_0= ruleEString ) )
            // InternalTourDsl.g:358:4: (lv_nombre_4_0= ruleEString )
            {
            // InternalTourDsl.g:358:4: (lv_nombre_4_0= ruleEString )
            // InternalTourDsl.g:359:5: lv_nombre_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getHotspotAccess().getNombreEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_6);
            lv_nombre_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getHotspotRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_4_0,
            						"edu.uniandes.tour.tourdsl.TourDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_COMA_5=(Token)match(input,RULE_COMA,FOLLOW_17); 

            			newLeafNode(this_COMA_5, grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_5());
            		
            this_TO_6=(Token)match(input,RULE_TO,FOLLOW_4); 

            			newLeafNode(this_TO_6, grammarAccess.getHotspotAccess().getTOTerminalRuleCall_6());
            		
            this_TWOPOINTS_7=(Token)match(input,RULE_TWOPOINTS,FOLLOW_5); 

            			newLeafNode(this_TWOPOINTS_7, grammarAccess.getHotspotAccess().getTWOPOINTSTerminalRuleCall_7());
            		
            // InternalTourDsl.g:388:3: ( (otherlv_8= RULE_STRING ) )
            // InternalTourDsl.g:389:4: (otherlv_8= RULE_STRING )
            {
            // InternalTourDsl.g:389:4: (otherlv_8= RULE_STRING )
            // InternalTourDsl.g:390:5: otherlv_8= RULE_STRING
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getHotspotRule());
            					}
            				
            otherlv_8=(Token)match(input,RULE_STRING,FOLLOW_6); 

            					newLeafNode(otherlv_8, grammarAccess.getHotspotAccess().getDirigePanoramaCrossReference_8_0());
            				

            }


            }

            this_COMA_9=(Token)match(input,RULE_COMA,FOLLOW_18); 

            			newLeafNode(this_COMA_9, grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_9());
            		
            // InternalTourDsl.g:405:3: ( (lv_posicion_10_0= rulePosicion ) )
            // InternalTourDsl.g:406:4: (lv_posicion_10_0= rulePosicion )
            {
            // InternalTourDsl.g:406:4: (lv_posicion_10_0= rulePosicion )
            // InternalTourDsl.g:407:5: lv_posicion_10_0= rulePosicion
            {

            					newCompositeNode(grammarAccess.getHotspotAccess().getPosicionPosicionParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_6);
            lv_posicion_10_0=rulePosicion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getHotspotRule());
            					}
            					set(
            						current,
            						"posicion",
            						lv_posicion_10_0,
            						"edu.uniandes.tour.tourdsl.TourDsl.Posicion");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_COMA_11=(Token)match(input,RULE_COMA,FOLLOW_13); 

            			newLeafNode(this_COMA_11, grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_11());
            		
            // InternalTourDsl.g:428:3: ( (lv_rotacion_12_0= ruleRotacion ) )
            // InternalTourDsl.g:429:4: (lv_rotacion_12_0= ruleRotacion )
            {
            // InternalTourDsl.g:429:4: (lv_rotacion_12_0= ruleRotacion )
            // InternalTourDsl.g:430:5: lv_rotacion_12_0= ruleRotacion
            {

            					newCompositeNode(grammarAccess.getHotspotAccess().getRotacionRotacionParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_11);
            lv_rotacion_12_0=ruleRotacion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getHotspotRule());
            					}
            					set(
            						current,
            						"rotacion",
            						lv_rotacion_12_0,
            						"edu.uniandes.tour.tourdsl.TourDsl.Rotacion");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_RBRACKET_13=(Token)match(input,RULE_RBRACKET,FOLLOW_2); 

            			newLeafNode(this_RBRACKET_13, grammarAccess.getHotspotAccess().getRBRACKETTerminalRuleCall_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHotspot"


    // $ANTLR start "entryRuleRotacionPanorama"
    // InternalTourDsl.g:455:1: entryRuleRotacionPanorama returns [EObject current=null] : iv_ruleRotacionPanorama= ruleRotacionPanorama EOF ;
    public final EObject entryRuleRotacionPanorama() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRotacionPanorama = null;


        try {
            // InternalTourDsl.g:455:57: (iv_ruleRotacionPanorama= ruleRotacionPanorama EOF )
            // InternalTourDsl.g:456:2: iv_ruleRotacionPanorama= ruleRotacionPanorama EOF
            {
             newCompositeNode(grammarAccess.getRotacionPanoramaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRotacionPanorama=ruleRotacionPanorama();

            state._fsp--;

             current =iv_ruleRotacionPanorama; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRotacionPanorama"


    // $ANTLR start "ruleRotacionPanorama"
    // InternalTourDsl.g:462:1: ruleRotacionPanorama returns [EObject current=null] : ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET ) ;
    public final EObject ruleRotacionPanorama() throws RecognitionException {
        EObject current = null;

        Token this_ROTATION_1=null;
        Token this_TWOPOINTS_2=null;
        Token this_LBRACKET_3=null;
        Token this_ROTX_4=null;
        Token this_TWOPOINTS_5=null;
        Token this_COMA_7=null;
        Token this_ROTY_8=null;
        Token this_TWOPOINTS_9=null;
        Token this_COMA_11=null;
        Token this_ROTZ_12=null;
        Token this_TWOPOINTS_13=null;
        Token this_RBRACKET_15=null;
        AntlrDatatypeRuleToken lv_x_6_0 = null;

        AntlrDatatypeRuleToken lv_y_10_0 = null;

        AntlrDatatypeRuleToken lv_z_14_0 = null;



        	enterRule();

        try {
            // InternalTourDsl.g:468:2: ( ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET ) )
            // InternalTourDsl.g:469:2: ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET )
            {
            // InternalTourDsl.g:469:2: ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET )
            // InternalTourDsl.g:470:3: () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET
            {
            // InternalTourDsl.g:470:3: ()
            // InternalTourDsl.g:471:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getRotacionPanoramaAccess().getRotPanoramaAction_0(),
            					current);
            			

            }

            this_ROTATION_1=(Token)match(input,RULE_ROTATION,FOLLOW_4); 

            			newLeafNode(this_ROTATION_1, grammarAccess.getRotacionPanoramaAccess().getROTATIONTerminalRuleCall_1());
            		
            this_TWOPOINTS_2=(Token)match(input,RULE_TWOPOINTS,FOLLOW_9); 

            			newLeafNode(this_TWOPOINTS_2, grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_2());
            		
            this_LBRACKET_3=(Token)match(input,RULE_LBRACKET,FOLLOW_19); 

            			newLeafNode(this_LBRACKET_3, grammarAccess.getRotacionPanoramaAccess().getLBRACKETTerminalRuleCall_3());
            		
            this_ROTX_4=(Token)match(input,RULE_ROTX,FOLLOW_4); 

            			newLeafNode(this_ROTX_4, grammarAccess.getRotacionPanoramaAccess().getROTXTerminalRuleCall_4());
            		
            this_TWOPOINTS_5=(Token)match(input,RULE_TWOPOINTS,FOLLOW_20); 

            			newLeafNode(this_TWOPOINTS_5, grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_5());
            		
            // InternalTourDsl.g:497:3: ( (lv_x_6_0= ruleEInt ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_INT) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalTourDsl.g:498:4: (lv_x_6_0= ruleEInt )
                    {
                    // InternalTourDsl.g:498:4: (lv_x_6_0= ruleEInt )
                    // InternalTourDsl.g:499:5: lv_x_6_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getRotacionPanoramaAccess().getXEIntParserRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_x_6_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRotacionPanoramaRule());
                    					}
                    					set(
                    						current,
                    						"x",
                    						lv_x_6_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_COMA_7=(Token)match(input,RULE_COMA,FOLLOW_21); 

            			newLeafNode(this_COMA_7, grammarAccess.getRotacionPanoramaAccess().getCOMATerminalRuleCall_7());
            		
            this_ROTY_8=(Token)match(input,RULE_ROTY,FOLLOW_4); 

            			newLeafNode(this_ROTY_8, grammarAccess.getRotacionPanoramaAccess().getROTYTerminalRuleCall_8());
            		
            this_TWOPOINTS_9=(Token)match(input,RULE_TWOPOINTS,FOLLOW_20); 

            			newLeafNode(this_TWOPOINTS_9, grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_9());
            		
            // InternalTourDsl.g:528:3: ( (lv_y_10_0= ruleEInt ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_INT) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalTourDsl.g:529:4: (lv_y_10_0= ruleEInt )
                    {
                    // InternalTourDsl.g:529:4: (lv_y_10_0= ruleEInt )
                    // InternalTourDsl.g:530:5: lv_y_10_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getRotacionPanoramaAccess().getYEIntParserRuleCall_10_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_y_10_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRotacionPanoramaRule());
                    					}
                    					set(
                    						current,
                    						"y",
                    						lv_y_10_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_COMA_11=(Token)match(input,RULE_COMA,FOLLOW_22); 

            			newLeafNode(this_COMA_11, grammarAccess.getRotacionPanoramaAccess().getCOMATerminalRuleCall_11());
            		
            this_ROTZ_12=(Token)match(input,RULE_ROTZ,FOLLOW_4); 

            			newLeafNode(this_ROTZ_12, grammarAccess.getRotacionPanoramaAccess().getROTZTerminalRuleCall_12());
            		
            this_TWOPOINTS_13=(Token)match(input,RULE_TWOPOINTS,FOLLOW_23); 

            			newLeafNode(this_TWOPOINTS_13, grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_13());
            		
            // InternalTourDsl.g:559:3: ( (lv_z_14_0= ruleEInt ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_INT) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalTourDsl.g:560:4: (lv_z_14_0= ruleEInt )
                    {
                    // InternalTourDsl.g:560:4: (lv_z_14_0= ruleEInt )
                    // InternalTourDsl.g:561:5: lv_z_14_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getRotacionPanoramaAccess().getZEIntParserRuleCall_14_0());
                    				
                    pushFollow(FOLLOW_11);
                    lv_z_14_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRotacionPanoramaRule());
                    					}
                    					set(
                    						current,
                    						"z",
                    						lv_z_14_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_RBRACKET_15=(Token)match(input,RULE_RBRACKET,FOLLOW_2); 

            			newLeafNode(this_RBRACKET_15, grammarAccess.getRotacionPanoramaAccess().getRBRACKETTerminalRuleCall_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRotacionPanorama"


    // $ANTLR start "entryRuleRotacion"
    // InternalTourDsl.g:586:1: entryRuleRotacion returns [EObject current=null] : iv_ruleRotacion= ruleRotacion EOF ;
    public final EObject entryRuleRotacion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRotacion = null;


        try {
            // InternalTourDsl.g:586:49: (iv_ruleRotacion= ruleRotacion EOF )
            // InternalTourDsl.g:587:2: iv_ruleRotacion= ruleRotacion EOF
            {
             newCompositeNode(grammarAccess.getRotacionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRotacion=ruleRotacion();

            state._fsp--;

             current =iv_ruleRotacion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRotacion"


    // $ANTLR start "ruleRotacion"
    // InternalTourDsl.g:593:1: ruleRotacion returns [EObject current=null] : ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET ) ;
    public final EObject ruleRotacion() throws RecognitionException {
        EObject current = null;

        Token this_ROTATION_1=null;
        Token this_TWOPOINTS_2=null;
        Token this_LBRACKET_3=null;
        Token this_ROTX_4=null;
        Token this_TWOPOINTS_5=null;
        Token this_COMA_7=null;
        Token this_ROTY_8=null;
        Token this_TWOPOINTS_9=null;
        Token this_COMA_11=null;
        Token this_ROTZ_12=null;
        Token this_TWOPOINTS_13=null;
        Token this_RBRACKET_15=null;
        AntlrDatatypeRuleToken lv_x_6_0 = null;

        AntlrDatatypeRuleToken lv_y_10_0 = null;

        AntlrDatatypeRuleToken lv_z_14_0 = null;



        	enterRule();

        try {
            // InternalTourDsl.g:599:2: ( ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET ) )
            // InternalTourDsl.g:600:2: ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET )
            {
            // InternalTourDsl.g:600:2: ( () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET )
            // InternalTourDsl.g:601:3: () this_ROTATION_1= RULE_ROTATION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_ROTX_4= RULE_ROTX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_ROTY_8= RULE_ROTY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_ROTZ_12= RULE_ROTZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET
            {
            // InternalTourDsl.g:601:3: ()
            // InternalTourDsl.g:602:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getRotacionAccess().getRotacionAction_0(),
            					current);
            			

            }

            this_ROTATION_1=(Token)match(input,RULE_ROTATION,FOLLOW_4); 

            			newLeafNode(this_ROTATION_1, grammarAccess.getRotacionAccess().getROTATIONTerminalRuleCall_1());
            		
            this_TWOPOINTS_2=(Token)match(input,RULE_TWOPOINTS,FOLLOW_9); 

            			newLeafNode(this_TWOPOINTS_2, grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_2());
            		
            this_LBRACKET_3=(Token)match(input,RULE_LBRACKET,FOLLOW_19); 

            			newLeafNode(this_LBRACKET_3, grammarAccess.getRotacionAccess().getLBRACKETTerminalRuleCall_3());
            		
            this_ROTX_4=(Token)match(input,RULE_ROTX,FOLLOW_4); 

            			newLeafNode(this_ROTX_4, grammarAccess.getRotacionAccess().getROTXTerminalRuleCall_4());
            		
            this_TWOPOINTS_5=(Token)match(input,RULE_TWOPOINTS,FOLLOW_20); 

            			newLeafNode(this_TWOPOINTS_5, grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_5());
            		
            // InternalTourDsl.g:628:3: ( (lv_x_6_0= ruleEInt ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_INT) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalTourDsl.g:629:4: (lv_x_6_0= ruleEInt )
                    {
                    // InternalTourDsl.g:629:4: (lv_x_6_0= ruleEInt )
                    // InternalTourDsl.g:630:5: lv_x_6_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getRotacionAccess().getXEIntParserRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_x_6_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRotacionRule());
                    					}
                    					set(
                    						current,
                    						"x",
                    						lv_x_6_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_COMA_7=(Token)match(input,RULE_COMA,FOLLOW_21); 

            			newLeafNode(this_COMA_7, grammarAccess.getRotacionAccess().getCOMATerminalRuleCall_7());
            		
            this_ROTY_8=(Token)match(input,RULE_ROTY,FOLLOW_4); 

            			newLeafNode(this_ROTY_8, grammarAccess.getRotacionAccess().getROTYTerminalRuleCall_8());
            		
            this_TWOPOINTS_9=(Token)match(input,RULE_TWOPOINTS,FOLLOW_20); 

            			newLeafNode(this_TWOPOINTS_9, grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_9());
            		
            // InternalTourDsl.g:659:3: ( (lv_y_10_0= ruleEInt ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_INT) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalTourDsl.g:660:4: (lv_y_10_0= ruleEInt )
                    {
                    // InternalTourDsl.g:660:4: (lv_y_10_0= ruleEInt )
                    // InternalTourDsl.g:661:5: lv_y_10_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getRotacionAccess().getYEIntParserRuleCall_10_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_y_10_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRotacionRule());
                    					}
                    					set(
                    						current,
                    						"y",
                    						lv_y_10_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_COMA_11=(Token)match(input,RULE_COMA,FOLLOW_22); 

            			newLeafNode(this_COMA_11, grammarAccess.getRotacionAccess().getCOMATerminalRuleCall_11());
            		
            this_ROTZ_12=(Token)match(input,RULE_ROTZ,FOLLOW_4); 

            			newLeafNode(this_ROTZ_12, grammarAccess.getRotacionAccess().getROTZTerminalRuleCall_12());
            		
            this_TWOPOINTS_13=(Token)match(input,RULE_TWOPOINTS,FOLLOW_23); 

            			newLeafNode(this_TWOPOINTS_13, grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_13());
            		
            // InternalTourDsl.g:690:3: ( (lv_z_14_0= ruleEInt ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_INT) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalTourDsl.g:691:4: (lv_z_14_0= ruleEInt )
                    {
                    // InternalTourDsl.g:691:4: (lv_z_14_0= ruleEInt )
                    // InternalTourDsl.g:692:5: lv_z_14_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getRotacionAccess().getZEIntParserRuleCall_14_0());
                    				
                    pushFollow(FOLLOW_11);
                    lv_z_14_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRotacionRule());
                    					}
                    					set(
                    						current,
                    						"z",
                    						lv_z_14_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_RBRACKET_15=(Token)match(input,RULE_RBRACKET,FOLLOW_2); 

            			newLeafNode(this_RBRACKET_15, grammarAccess.getRotacionAccess().getRBRACKETTerminalRuleCall_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRotacion"


    // $ANTLR start "entryRulePosicion"
    // InternalTourDsl.g:717:1: entryRulePosicion returns [EObject current=null] : iv_rulePosicion= rulePosicion EOF ;
    public final EObject entryRulePosicion() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePosicion = null;


        try {
            // InternalTourDsl.g:717:49: (iv_rulePosicion= rulePosicion EOF )
            // InternalTourDsl.g:718:2: iv_rulePosicion= rulePosicion EOF
            {
             newCompositeNode(grammarAccess.getPosicionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePosicion=rulePosicion();

            state._fsp--;

             current =iv_rulePosicion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePosicion"


    // $ANTLR start "rulePosicion"
    // InternalTourDsl.g:724:1: rulePosicion returns [EObject current=null] : ( () this_POSITION_1= RULE_POSITION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_POSX_4= RULE_POSX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_POSY_8= RULE_POSY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_POSZ_12= RULE_POSZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET ) ;
    public final EObject rulePosicion() throws RecognitionException {
        EObject current = null;

        Token this_POSITION_1=null;
        Token this_TWOPOINTS_2=null;
        Token this_LBRACKET_3=null;
        Token this_POSX_4=null;
        Token this_TWOPOINTS_5=null;
        Token this_COMA_7=null;
        Token this_POSY_8=null;
        Token this_TWOPOINTS_9=null;
        Token this_COMA_11=null;
        Token this_POSZ_12=null;
        Token this_TWOPOINTS_13=null;
        Token this_RBRACKET_15=null;
        AntlrDatatypeRuleToken lv_x_6_0 = null;

        AntlrDatatypeRuleToken lv_y_10_0 = null;

        AntlrDatatypeRuleToken lv_z_14_0 = null;



        	enterRule();

        try {
            // InternalTourDsl.g:730:2: ( ( () this_POSITION_1= RULE_POSITION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_POSX_4= RULE_POSX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_POSY_8= RULE_POSY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_POSZ_12= RULE_POSZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET ) )
            // InternalTourDsl.g:731:2: ( () this_POSITION_1= RULE_POSITION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_POSX_4= RULE_POSX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_POSY_8= RULE_POSY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_POSZ_12= RULE_POSZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET )
            {
            // InternalTourDsl.g:731:2: ( () this_POSITION_1= RULE_POSITION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_POSX_4= RULE_POSX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_POSY_8= RULE_POSY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_POSZ_12= RULE_POSZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET )
            // InternalTourDsl.g:732:3: () this_POSITION_1= RULE_POSITION this_TWOPOINTS_2= RULE_TWOPOINTS this_LBRACKET_3= RULE_LBRACKET this_POSX_4= RULE_POSX this_TWOPOINTS_5= RULE_TWOPOINTS ( (lv_x_6_0= ruleEInt ) )? this_COMA_7= RULE_COMA this_POSY_8= RULE_POSY this_TWOPOINTS_9= RULE_TWOPOINTS ( (lv_y_10_0= ruleEInt ) )? this_COMA_11= RULE_COMA this_POSZ_12= RULE_POSZ this_TWOPOINTS_13= RULE_TWOPOINTS ( (lv_z_14_0= ruleEInt ) )? this_RBRACKET_15= RULE_RBRACKET
            {
            // InternalTourDsl.g:732:3: ()
            // InternalTourDsl.g:733:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPosicionAccess().getPosicionAction_0(),
            					current);
            			

            }

            this_POSITION_1=(Token)match(input,RULE_POSITION,FOLLOW_4); 

            			newLeafNode(this_POSITION_1, grammarAccess.getPosicionAccess().getPOSITIONTerminalRuleCall_1());
            		
            this_TWOPOINTS_2=(Token)match(input,RULE_TWOPOINTS,FOLLOW_9); 

            			newLeafNode(this_TWOPOINTS_2, grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_2());
            		
            this_LBRACKET_3=(Token)match(input,RULE_LBRACKET,FOLLOW_24); 

            			newLeafNode(this_LBRACKET_3, grammarAccess.getPosicionAccess().getLBRACKETTerminalRuleCall_3());
            		
            this_POSX_4=(Token)match(input,RULE_POSX,FOLLOW_4); 

            			newLeafNode(this_POSX_4, grammarAccess.getPosicionAccess().getPOSXTerminalRuleCall_4());
            		
            this_TWOPOINTS_5=(Token)match(input,RULE_TWOPOINTS,FOLLOW_20); 

            			newLeafNode(this_TWOPOINTS_5, grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_5());
            		
            // InternalTourDsl.g:759:3: ( (lv_x_6_0= ruleEInt ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_INT) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalTourDsl.g:760:4: (lv_x_6_0= ruleEInt )
                    {
                    // InternalTourDsl.g:760:4: (lv_x_6_0= ruleEInt )
                    // InternalTourDsl.g:761:5: lv_x_6_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getPosicionAccess().getXEIntParserRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_x_6_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPosicionRule());
                    					}
                    					set(
                    						current,
                    						"x",
                    						lv_x_6_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_COMA_7=(Token)match(input,RULE_COMA,FOLLOW_25); 

            			newLeafNode(this_COMA_7, grammarAccess.getPosicionAccess().getCOMATerminalRuleCall_7());
            		
            this_POSY_8=(Token)match(input,RULE_POSY,FOLLOW_4); 

            			newLeafNode(this_POSY_8, grammarAccess.getPosicionAccess().getPOSYTerminalRuleCall_8());
            		
            this_TWOPOINTS_9=(Token)match(input,RULE_TWOPOINTS,FOLLOW_20); 

            			newLeafNode(this_TWOPOINTS_9, grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_9());
            		
            // InternalTourDsl.g:790:3: ( (lv_y_10_0= ruleEInt ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_INT) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalTourDsl.g:791:4: (lv_y_10_0= ruleEInt )
                    {
                    // InternalTourDsl.g:791:4: (lv_y_10_0= ruleEInt )
                    // InternalTourDsl.g:792:5: lv_y_10_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getPosicionAccess().getYEIntParserRuleCall_10_0());
                    				
                    pushFollow(FOLLOW_6);
                    lv_y_10_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPosicionRule());
                    					}
                    					set(
                    						current,
                    						"y",
                    						lv_y_10_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_COMA_11=(Token)match(input,RULE_COMA,FOLLOW_26); 

            			newLeafNode(this_COMA_11, grammarAccess.getPosicionAccess().getCOMATerminalRuleCall_11());
            		
            this_POSZ_12=(Token)match(input,RULE_POSZ,FOLLOW_4); 

            			newLeafNode(this_POSZ_12, grammarAccess.getPosicionAccess().getPOSZTerminalRuleCall_12());
            		
            this_TWOPOINTS_13=(Token)match(input,RULE_TWOPOINTS,FOLLOW_23); 

            			newLeafNode(this_TWOPOINTS_13, grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_13());
            		
            // InternalTourDsl.g:821:3: ( (lv_z_14_0= ruleEInt ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==RULE_INT) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalTourDsl.g:822:4: (lv_z_14_0= ruleEInt )
                    {
                    // InternalTourDsl.g:822:4: (lv_z_14_0= ruleEInt )
                    // InternalTourDsl.g:823:5: lv_z_14_0= ruleEInt
                    {

                    					newCompositeNode(grammarAccess.getPosicionAccess().getZEIntParserRuleCall_14_0());
                    				
                    pushFollow(FOLLOW_11);
                    lv_z_14_0=ruleEInt();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPosicionRule());
                    					}
                    					set(
                    						current,
                    						"z",
                    						lv_z_14_0,
                    						"edu.uniandes.tour.tourdsl.TourDsl.EInt");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_RBRACKET_15=(Token)match(input,RULE_RBRACKET,FOLLOW_2); 

            			newLeafNode(this_RBRACKET_15, grammarAccess.getPosicionAccess().getRBRACKETTerminalRuleCall_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePosicion"


    // $ANTLR start "entryRuleEInt"
    // InternalTourDsl.g:848:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalTourDsl.g:848:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalTourDsl.g:849:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalTourDsl.g:855:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_INT_0= RULE_INT ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;


        	enterRule();

        try {
            // InternalTourDsl.g:861:2: (this_INT_0= RULE_INT )
            // InternalTourDsl.g:862:2: this_INT_0= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            		current.merge(this_INT_0);
            	

            		newLeafNode(this_INT_0, grammarAccess.getEIntAccess().getINTTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEString"
    // InternalTourDsl.g:872:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalTourDsl.g:872:47: (iv_ruleEString= ruleEString EOF )
            // InternalTourDsl.g:873:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalTourDsl.g:879:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_STRING_0= RULE_STRING ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;


        	enterRule();

        try {
            // InternalTourDsl.g:885:2: (this_STRING_0= RULE_STRING )
            // InternalTourDsl.g:886:2: this_STRING_0= RULE_STRING
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            		current.merge(this_STRING_0);
            	

            		newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000410L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000490L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000001000080L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000001000800L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000800000L});

}