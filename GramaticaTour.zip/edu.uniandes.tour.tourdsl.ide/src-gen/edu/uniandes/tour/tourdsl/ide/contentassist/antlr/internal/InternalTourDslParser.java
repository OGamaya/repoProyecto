package edu.uniandes.tour.tourdsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import edu.uniandes.tour.tourdsl.services.TourDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalTourDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_STRING", "RULE_LBRACKET", "RULE_NAME", "RULE_TWOPOINTS", "RULE_COMA", "RULE_PLACES", "RULE_LPARENTISISCUADRADO", "RULE_RPARENTISISCUADRADO", "RULE_RBRACKET", "RULE_DESCRIPTION", "RULE_PATHS", "RULE_TO", "RULE_ROTATION", "RULE_ROTX", "RULE_ROTY", "RULE_ROTZ", "RULE_POSITION", "RULE_POSX", "RULE_POSY", "RULE_POSZ", "RULE_EQUALS", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER"
    };
    public static final int RULE_LBRACKET=6;
    public static final int RULE_COMA=9;
    public static final int RULE_PATHS=15;
    public static final int RULE_TO=16;
    public static final int RULE_NAME=7;
    public static final int RULE_PLACES=10;
    public static final int RULE_STRING=5;
    public static final int RULE_ROTX=18;
    public static final int RULE_ROTY=19;
    public static final int RULE_ROTZ=20;
    public static final int RULE_POSITION=21;
    public static final int RULE_SL_COMMENT=28;
    public static final int RULE_RPARENTISISCUADRADO=12;
    public static final int RULE_EQUALS=25;
    public static final int RULE_LPARENTISISCUADRADO=11;
    public static final int EOF=-1;
    public static final int RULE_POSX=22;
    public static final int RULE_ID=26;
    public static final int RULE_WS=29;
    public static final int RULE_DESCRIPTION=14;
    public static final int RULE_ROTATION=17;
    public static final int RULE_ANY_OTHER=30;
    public static final int RULE_POSZ=24;
    public static final int RULE_POSY=23;
    public static final int RULE_INT=4;
    public static final int RULE_TWOPOINTS=8;
    public static final int RULE_ML_COMMENT=27;
    public static final int RULE_RBRACKET=13;

    // delegates
    // delegators


        public InternalTourDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalTourDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalTourDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalTourDsl.g"; }


    	private TourDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(TourDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleTour"
    // InternalTourDsl.g:53:1: entryRuleTour : ruleTour EOF ;
    public final void entryRuleTour() throws RecognitionException {
        try {
            // InternalTourDsl.g:54:1: ( ruleTour EOF )
            // InternalTourDsl.g:55:1: ruleTour EOF
            {
             before(grammarAccess.getTourRule()); 
            pushFollow(FOLLOW_1);
            ruleTour();

            state._fsp--;

             after(grammarAccess.getTourRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTour"


    // $ANTLR start "ruleTour"
    // InternalTourDsl.g:62:1: ruleTour : ( ( rule__Tour__Group__0 ) ) ;
    public final void ruleTour() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:66:2: ( ( ( rule__Tour__Group__0 ) ) )
            // InternalTourDsl.g:67:2: ( ( rule__Tour__Group__0 ) )
            {
            // InternalTourDsl.g:67:2: ( ( rule__Tour__Group__0 ) )
            // InternalTourDsl.g:68:3: ( rule__Tour__Group__0 )
            {
             before(grammarAccess.getTourAccess().getGroup()); 
            // InternalTourDsl.g:69:3: ( rule__Tour__Group__0 )
            // InternalTourDsl.g:69:4: rule__Tour__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Tour__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTourAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTour"


    // $ANTLR start "entryRulePanorama"
    // InternalTourDsl.g:78:1: entryRulePanorama : rulePanorama EOF ;
    public final void entryRulePanorama() throws RecognitionException {
        try {
            // InternalTourDsl.g:79:1: ( rulePanorama EOF )
            // InternalTourDsl.g:80:1: rulePanorama EOF
            {
             before(grammarAccess.getPanoramaRule()); 
            pushFollow(FOLLOW_1);
            rulePanorama();

            state._fsp--;

             after(grammarAccess.getPanoramaRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePanorama"


    // $ANTLR start "rulePanorama"
    // InternalTourDsl.g:87:1: rulePanorama : ( ( rule__Panorama__Group__0 ) ) ;
    public final void rulePanorama() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:91:2: ( ( ( rule__Panorama__Group__0 ) ) )
            // InternalTourDsl.g:92:2: ( ( rule__Panorama__Group__0 ) )
            {
            // InternalTourDsl.g:92:2: ( ( rule__Panorama__Group__0 ) )
            // InternalTourDsl.g:93:3: ( rule__Panorama__Group__0 )
            {
             before(grammarAccess.getPanoramaAccess().getGroup()); 
            // InternalTourDsl.g:94:3: ( rule__Panorama__Group__0 )
            // InternalTourDsl.g:94:4: rule__Panorama__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Panorama__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPanoramaAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePanorama"


    // $ANTLR start "entryRuleHotspot"
    // InternalTourDsl.g:103:1: entryRuleHotspot : ruleHotspot EOF ;
    public final void entryRuleHotspot() throws RecognitionException {
        try {
            // InternalTourDsl.g:104:1: ( ruleHotspot EOF )
            // InternalTourDsl.g:105:1: ruleHotspot EOF
            {
             before(grammarAccess.getHotspotRule()); 
            pushFollow(FOLLOW_1);
            ruleHotspot();

            state._fsp--;

             after(grammarAccess.getHotspotRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleHotspot"


    // $ANTLR start "ruleHotspot"
    // InternalTourDsl.g:112:1: ruleHotspot : ( ( rule__Hotspot__Group__0 ) ) ;
    public final void ruleHotspot() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:116:2: ( ( ( rule__Hotspot__Group__0 ) ) )
            // InternalTourDsl.g:117:2: ( ( rule__Hotspot__Group__0 ) )
            {
            // InternalTourDsl.g:117:2: ( ( rule__Hotspot__Group__0 ) )
            // InternalTourDsl.g:118:3: ( rule__Hotspot__Group__0 )
            {
             before(grammarAccess.getHotspotAccess().getGroup()); 
            // InternalTourDsl.g:119:3: ( rule__Hotspot__Group__0 )
            // InternalTourDsl.g:119:4: rule__Hotspot__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getHotspotAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleHotspot"


    // $ANTLR start "entryRuleRotacionPanorama"
    // InternalTourDsl.g:128:1: entryRuleRotacionPanorama : ruleRotacionPanorama EOF ;
    public final void entryRuleRotacionPanorama() throws RecognitionException {
        try {
            // InternalTourDsl.g:129:1: ( ruleRotacionPanorama EOF )
            // InternalTourDsl.g:130:1: ruleRotacionPanorama EOF
            {
             before(grammarAccess.getRotacionPanoramaRule()); 
            pushFollow(FOLLOW_1);
            ruleRotacionPanorama();

            state._fsp--;

             after(grammarAccess.getRotacionPanoramaRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRotacionPanorama"


    // $ANTLR start "ruleRotacionPanorama"
    // InternalTourDsl.g:137:1: ruleRotacionPanorama : ( ( rule__RotacionPanorama__Group__0 ) ) ;
    public final void ruleRotacionPanorama() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:141:2: ( ( ( rule__RotacionPanorama__Group__0 ) ) )
            // InternalTourDsl.g:142:2: ( ( rule__RotacionPanorama__Group__0 ) )
            {
            // InternalTourDsl.g:142:2: ( ( rule__RotacionPanorama__Group__0 ) )
            // InternalTourDsl.g:143:3: ( rule__RotacionPanorama__Group__0 )
            {
             before(grammarAccess.getRotacionPanoramaAccess().getGroup()); 
            // InternalTourDsl.g:144:3: ( rule__RotacionPanorama__Group__0 )
            // InternalTourDsl.g:144:4: rule__RotacionPanorama__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRotacionPanoramaAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRotacionPanorama"


    // $ANTLR start "entryRuleRotacion"
    // InternalTourDsl.g:153:1: entryRuleRotacion : ruleRotacion EOF ;
    public final void entryRuleRotacion() throws RecognitionException {
        try {
            // InternalTourDsl.g:154:1: ( ruleRotacion EOF )
            // InternalTourDsl.g:155:1: ruleRotacion EOF
            {
             before(grammarAccess.getRotacionRule()); 
            pushFollow(FOLLOW_1);
            ruleRotacion();

            state._fsp--;

             after(grammarAccess.getRotacionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRotacion"


    // $ANTLR start "ruleRotacion"
    // InternalTourDsl.g:162:1: ruleRotacion : ( ( rule__Rotacion__Group__0 ) ) ;
    public final void ruleRotacion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:166:2: ( ( ( rule__Rotacion__Group__0 ) ) )
            // InternalTourDsl.g:167:2: ( ( rule__Rotacion__Group__0 ) )
            {
            // InternalTourDsl.g:167:2: ( ( rule__Rotacion__Group__0 ) )
            // InternalTourDsl.g:168:3: ( rule__Rotacion__Group__0 )
            {
             before(grammarAccess.getRotacionAccess().getGroup()); 
            // InternalTourDsl.g:169:3: ( rule__Rotacion__Group__0 )
            // InternalTourDsl.g:169:4: rule__Rotacion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRotacionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRotacion"


    // $ANTLR start "entryRulePosicion"
    // InternalTourDsl.g:178:1: entryRulePosicion : rulePosicion EOF ;
    public final void entryRulePosicion() throws RecognitionException {
        try {
            // InternalTourDsl.g:179:1: ( rulePosicion EOF )
            // InternalTourDsl.g:180:1: rulePosicion EOF
            {
             before(grammarAccess.getPosicionRule()); 
            pushFollow(FOLLOW_1);
            rulePosicion();

            state._fsp--;

             after(grammarAccess.getPosicionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePosicion"


    // $ANTLR start "rulePosicion"
    // InternalTourDsl.g:187:1: rulePosicion : ( ( rule__Posicion__Group__0 ) ) ;
    public final void rulePosicion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:191:2: ( ( ( rule__Posicion__Group__0 ) ) )
            // InternalTourDsl.g:192:2: ( ( rule__Posicion__Group__0 ) )
            {
            // InternalTourDsl.g:192:2: ( ( rule__Posicion__Group__0 ) )
            // InternalTourDsl.g:193:3: ( rule__Posicion__Group__0 )
            {
             before(grammarAccess.getPosicionAccess().getGroup()); 
            // InternalTourDsl.g:194:3: ( rule__Posicion__Group__0 )
            // InternalTourDsl.g:194:4: rule__Posicion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Posicion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPosicionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePosicion"


    // $ANTLR start "entryRuleEInt"
    // InternalTourDsl.g:203:1: entryRuleEInt : ruleEInt EOF ;
    public final void entryRuleEInt() throws RecognitionException {
        try {
            // InternalTourDsl.g:204:1: ( ruleEInt EOF )
            // InternalTourDsl.g:205:1: ruleEInt EOF
            {
             before(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getEIntRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalTourDsl.g:212:1: ruleEInt : ( RULE_INT ) ;
    public final void ruleEInt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:216:2: ( ( RULE_INT ) )
            // InternalTourDsl.g:217:2: ( RULE_INT )
            {
            // InternalTourDsl.g:217:2: ( RULE_INT )
            // InternalTourDsl.g:218:3: RULE_INT
            {
             before(grammarAccess.getEIntAccess().getINTTerminalRuleCall()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEIntAccess().getINTTerminalRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEString"
    // InternalTourDsl.g:228:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalTourDsl.g:229:1: ( ruleEString EOF )
            // InternalTourDsl.g:230:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalTourDsl.g:237:1: ruleEString : ( RULE_STRING ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:241:2: ( ( RULE_STRING ) )
            // InternalTourDsl.g:242:2: ( RULE_STRING )
            {
            // InternalTourDsl.g:242:2: ( RULE_STRING )
            // InternalTourDsl.g:243:3: RULE_STRING
            {
             before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "rule__Tour__Group__0"
    // InternalTourDsl.g:252:1: rule__Tour__Group__0 : rule__Tour__Group__0__Impl rule__Tour__Group__1 ;
    public final void rule__Tour__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:256:1: ( rule__Tour__Group__0__Impl rule__Tour__Group__1 )
            // InternalTourDsl.g:257:2: rule__Tour__Group__0__Impl rule__Tour__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Tour__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__0"


    // $ANTLR start "rule__Tour__Group__0__Impl"
    // InternalTourDsl.g:264:1: rule__Tour__Group__0__Impl : ( () ) ;
    public final void rule__Tour__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:268:1: ( ( () ) )
            // InternalTourDsl.g:269:1: ( () )
            {
            // InternalTourDsl.g:269:1: ( () )
            // InternalTourDsl.g:270:2: ()
            {
             before(grammarAccess.getTourAccess().getTourAction_0()); 
            // InternalTourDsl.g:271:2: ()
            // InternalTourDsl.g:271:3: 
            {
            }

             after(grammarAccess.getTourAccess().getTourAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__0__Impl"


    // $ANTLR start "rule__Tour__Group__1"
    // InternalTourDsl.g:279:1: rule__Tour__Group__1 : rule__Tour__Group__1__Impl rule__Tour__Group__2 ;
    public final void rule__Tour__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:283:1: ( rule__Tour__Group__1__Impl rule__Tour__Group__2 )
            // InternalTourDsl.g:284:2: rule__Tour__Group__1__Impl rule__Tour__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Tour__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__1"


    // $ANTLR start "rule__Tour__Group__1__Impl"
    // InternalTourDsl.g:291:1: rule__Tour__Group__1__Impl : ( RULE_LBRACKET ) ;
    public final void rule__Tour__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:295:1: ( ( RULE_LBRACKET ) )
            // InternalTourDsl.g:296:1: ( RULE_LBRACKET )
            {
            // InternalTourDsl.g:296:1: ( RULE_LBRACKET )
            // InternalTourDsl.g:297:2: RULE_LBRACKET
            {
             before(grammarAccess.getTourAccess().getLBRACKETTerminalRuleCall_1()); 
            match(input,RULE_LBRACKET,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getLBRACKETTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__1__Impl"


    // $ANTLR start "rule__Tour__Group__2"
    // InternalTourDsl.g:306:1: rule__Tour__Group__2 : rule__Tour__Group__2__Impl rule__Tour__Group__3 ;
    public final void rule__Tour__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:310:1: ( rule__Tour__Group__2__Impl rule__Tour__Group__3 )
            // InternalTourDsl.g:311:2: rule__Tour__Group__2__Impl rule__Tour__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Tour__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__2"


    // $ANTLR start "rule__Tour__Group__2__Impl"
    // InternalTourDsl.g:318:1: rule__Tour__Group__2__Impl : ( RULE_NAME ) ;
    public final void rule__Tour__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:322:1: ( ( RULE_NAME ) )
            // InternalTourDsl.g:323:1: ( RULE_NAME )
            {
            // InternalTourDsl.g:323:1: ( RULE_NAME )
            // InternalTourDsl.g:324:2: RULE_NAME
            {
             before(grammarAccess.getTourAccess().getNAMETerminalRuleCall_2()); 
            match(input,RULE_NAME,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getNAMETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__2__Impl"


    // $ANTLR start "rule__Tour__Group__3"
    // InternalTourDsl.g:333:1: rule__Tour__Group__3 : rule__Tour__Group__3__Impl rule__Tour__Group__4 ;
    public final void rule__Tour__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:337:1: ( rule__Tour__Group__3__Impl rule__Tour__Group__4 )
            // InternalTourDsl.g:338:2: rule__Tour__Group__3__Impl rule__Tour__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Tour__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__3"


    // $ANTLR start "rule__Tour__Group__3__Impl"
    // InternalTourDsl.g:345:1: rule__Tour__Group__3__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Tour__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:349:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:350:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:350:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:351:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getTourAccess().getTWOPOINTSTerminalRuleCall_3()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getTWOPOINTSTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__3__Impl"


    // $ANTLR start "rule__Tour__Group__4"
    // InternalTourDsl.g:360:1: rule__Tour__Group__4 : rule__Tour__Group__4__Impl rule__Tour__Group__5 ;
    public final void rule__Tour__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:364:1: ( rule__Tour__Group__4__Impl rule__Tour__Group__5 )
            // InternalTourDsl.g:365:2: rule__Tour__Group__4__Impl rule__Tour__Group__5
            {
            pushFollow(FOLLOW_7);
            rule__Tour__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__4"


    // $ANTLR start "rule__Tour__Group__4__Impl"
    // InternalTourDsl.g:372:1: rule__Tour__Group__4__Impl : ( ( rule__Tour__NombreAssignment_4 ) ) ;
    public final void rule__Tour__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:376:1: ( ( ( rule__Tour__NombreAssignment_4 ) ) )
            // InternalTourDsl.g:377:1: ( ( rule__Tour__NombreAssignment_4 ) )
            {
            // InternalTourDsl.g:377:1: ( ( rule__Tour__NombreAssignment_4 ) )
            // InternalTourDsl.g:378:2: ( rule__Tour__NombreAssignment_4 )
            {
             before(grammarAccess.getTourAccess().getNombreAssignment_4()); 
            // InternalTourDsl.g:379:2: ( rule__Tour__NombreAssignment_4 )
            // InternalTourDsl.g:379:3: rule__Tour__NombreAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Tour__NombreAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTourAccess().getNombreAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__4__Impl"


    // $ANTLR start "rule__Tour__Group__5"
    // InternalTourDsl.g:387:1: rule__Tour__Group__5 : rule__Tour__Group__5__Impl rule__Tour__Group__6 ;
    public final void rule__Tour__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:391:1: ( rule__Tour__Group__5__Impl rule__Tour__Group__6 )
            // InternalTourDsl.g:392:2: rule__Tour__Group__5__Impl rule__Tour__Group__6
            {
            pushFollow(FOLLOW_8);
            rule__Tour__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__5"


    // $ANTLR start "rule__Tour__Group__5__Impl"
    // InternalTourDsl.g:399:1: rule__Tour__Group__5__Impl : ( RULE_COMA ) ;
    public final void rule__Tour__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:403:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:404:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:404:1: ( RULE_COMA )
            // InternalTourDsl.g:405:2: RULE_COMA
            {
             before(grammarAccess.getTourAccess().getCOMATerminalRuleCall_5()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getCOMATerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__5__Impl"


    // $ANTLR start "rule__Tour__Group__6"
    // InternalTourDsl.g:414:1: rule__Tour__Group__6 : rule__Tour__Group__6__Impl rule__Tour__Group__7 ;
    public final void rule__Tour__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:418:1: ( rule__Tour__Group__6__Impl rule__Tour__Group__7 )
            // InternalTourDsl.g:419:2: rule__Tour__Group__6__Impl rule__Tour__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__Tour__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__6"


    // $ANTLR start "rule__Tour__Group__6__Impl"
    // InternalTourDsl.g:426:1: rule__Tour__Group__6__Impl : ( RULE_PLACES ) ;
    public final void rule__Tour__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:430:1: ( ( RULE_PLACES ) )
            // InternalTourDsl.g:431:1: ( RULE_PLACES )
            {
            // InternalTourDsl.g:431:1: ( RULE_PLACES )
            // InternalTourDsl.g:432:2: RULE_PLACES
            {
             before(grammarAccess.getTourAccess().getPLACESTerminalRuleCall_6()); 
            match(input,RULE_PLACES,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getPLACESTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__6__Impl"


    // $ANTLR start "rule__Tour__Group__7"
    // InternalTourDsl.g:441:1: rule__Tour__Group__7 : rule__Tour__Group__7__Impl rule__Tour__Group__8 ;
    public final void rule__Tour__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:445:1: ( rule__Tour__Group__7__Impl rule__Tour__Group__8 )
            // InternalTourDsl.g:446:2: rule__Tour__Group__7__Impl rule__Tour__Group__8
            {
            pushFollow(FOLLOW_9);
            rule__Tour__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__7"


    // $ANTLR start "rule__Tour__Group__7__Impl"
    // InternalTourDsl.g:453:1: rule__Tour__Group__7__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Tour__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:457:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:458:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:458:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:459:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getTourAccess().getTWOPOINTSTerminalRuleCall_7()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getTWOPOINTSTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__7__Impl"


    // $ANTLR start "rule__Tour__Group__8"
    // InternalTourDsl.g:468:1: rule__Tour__Group__8 : rule__Tour__Group__8__Impl rule__Tour__Group__9 ;
    public final void rule__Tour__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:472:1: ( rule__Tour__Group__8__Impl rule__Tour__Group__9 )
            // InternalTourDsl.g:473:2: rule__Tour__Group__8__Impl rule__Tour__Group__9
            {
            pushFollow(FOLLOW_3);
            rule__Tour__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__8"


    // $ANTLR start "rule__Tour__Group__8__Impl"
    // InternalTourDsl.g:480:1: rule__Tour__Group__8__Impl : ( RULE_LPARENTISISCUADRADO ) ;
    public final void rule__Tour__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:484:1: ( ( RULE_LPARENTISISCUADRADO ) )
            // InternalTourDsl.g:485:1: ( RULE_LPARENTISISCUADRADO )
            {
            // InternalTourDsl.g:485:1: ( RULE_LPARENTISISCUADRADO )
            // InternalTourDsl.g:486:2: RULE_LPARENTISISCUADRADO
            {
             before(grammarAccess.getTourAccess().getLPARENTISISCUADRADOTerminalRuleCall_8()); 
            match(input,RULE_LPARENTISISCUADRADO,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getLPARENTISISCUADRADOTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__8__Impl"


    // $ANTLR start "rule__Tour__Group__9"
    // InternalTourDsl.g:495:1: rule__Tour__Group__9 : rule__Tour__Group__9__Impl rule__Tour__Group__10 ;
    public final void rule__Tour__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:499:1: ( rule__Tour__Group__9__Impl rule__Tour__Group__10 )
            // InternalTourDsl.g:500:2: rule__Tour__Group__9__Impl rule__Tour__Group__10
            {
            pushFollow(FOLLOW_10);
            rule__Tour__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__9"


    // $ANTLR start "rule__Tour__Group__9__Impl"
    // InternalTourDsl.g:507:1: rule__Tour__Group__9__Impl : ( ( ( rule__Tour__PanoramaAssignment_9 ) ) ( ( rule__Tour__PanoramaAssignment_9 )* ) ) ;
    public final void rule__Tour__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:511:1: ( ( ( ( rule__Tour__PanoramaAssignment_9 ) ) ( ( rule__Tour__PanoramaAssignment_9 )* ) ) )
            // InternalTourDsl.g:512:1: ( ( ( rule__Tour__PanoramaAssignment_9 ) ) ( ( rule__Tour__PanoramaAssignment_9 )* ) )
            {
            // InternalTourDsl.g:512:1: ( ( ( rule__Tour__PanoramaAssignment_9 ) ) ( ( rule__Tour__PanoramaAssignment_9 )* ) )
            // InternalTourDsl.g:513:2: ( ( rule__Tour__PanoramaAssignment_9 ) ) ( ( rule__Tour__PanoramaAssignment_9 )* )
            {
            // InternalTourDsl.g:513:2: ( ( rule__Tour__PanoramaAssignment_9 ) )
            // InternalTourDsl.g:514:3: ( rule__Tour__PanoramaAssignment_9 )
            {
             before(grammarAccess.getTourAccess().getPanoramaAssignment_9()); 
            // InternalTourDsl.g:515:3: ( rule__Tour__PanoramaAssignment_9 )
            // InternalTourDsl.g:515:4: rule__Tour__PanoramaAssignment_9
            {
            pushFollow(FOLLOW_11);
            rule__Tour__PanoramaAssignment_9();

            state._fsp--;


            }

             after(grammarAccess.getTourAccess().getPanoramaAssignment_9()); 

            }

            // InternalTourDsl.g:518:2: ( ( rule__Tour__PanoramaAssignment_9 )* )
            // InternalTourDsl.g:519:3: ( rule__Tour__PanoramaAssignment_9 )*
            {
             before(grammarAccess.getTourAccess().getPanoramaAssignment_9()); 
            // InternalTourDsl.g:520:3: ( rule__Tour__PanoramaAssignment_9 )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==RULE_LBRACKET) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalTourDsl.g:520:4: rule__Tour__PanoramaAssignment_9
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__Tour__PanoramaAssignment_9();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getTourAccess().getPanoramaAssignment_9()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__9__Impl"


    // $ANTLR start "rule__Tour__Group__10"
    // InternalTourDsl.g:529:1: rule__Tour__Group__10 : rule__Tour__Group__10__Impl rule__Tour__Group__11 ;
    public final void rule__Tour__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:533:1: ( rule__Tour__Group__10__Impl rule__Tour__Group__11 )
            // InternalTourDsl.g:534:2: rule__Tour__Group__10__Impl rule__Tour__Group__11
            {
            pushFollow(FOLLOW_12);
            rule__Tour__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Tour__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__10"


    // $ANTLR start "rule__Tour__Group__10__Impl"
    // InternalTourDsl.g:541:1: rule__Tour__Group__10__Impl : ( RULE_RPARENTISISCUADRADO ) ;
    public final void rule__Tour__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:545:1: ( ( RULE_RPARENTISISCUADRADO ) )
            // InternalTourDsl.g:546:1: ( RULE_RPARENTISISCUADRADO )
            {
            // InternalTourDsl.g:546:1: ( RULE_RPARENTISISCUADRADO )
            // InternalTourDsl.g:547:2: RULE_RPARENTISISCUADRADO
            {
             before(grammarAccess.getTourAccess().getRPARENTISISCUADRADOTerminalRuleCall_10()); 
            match(input,RULE_RPARENTISISCUADRADO,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getRPARENTISISCUADRADOTerminalRuleCall_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__10__Impl"


    // $ANTLR start "rule__Tour__Group__11"
    // InternalTourDsl.g:556:1: rule__Tour__Group__11 : rule__Tour__Group__11__Impl ;
    public final void rule__Tour__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:560:1: ( rule__Tour__Group__11__Impl )
            // InternalTourDsl.g:561:2: rule__Tour__Group__11__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Tour__Group__11__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__11"


    // $ANTLR start "rule__Tour__Group__11__Impl"
    // InternalTourDsl.g:567:1: rule__Tour__Group__11__Impl : ( RULE_RBRACKET ) ;
    public final void rule__Tour__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:571:1: ( ( RULE_RBRACKET ) )
            // InternalTourDsl.g:572:1: ( RULE_RBRACKET )
            {
            // InternalTourDsl.g:572:1: ( RULE_RBRACKET )
            // InternalTourDsl.g:573:2: RULE_RBRACKET
            {
             before(grammarAccess.getTourAccess().getRBRACKETTerminalRuleCall_11()); 
            match(input,RULE_RBRACKET,FOLLOW_2); 
             after(grammarAccess.getTourAccess().getRBRACKETTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__Group__11__Impl"


    // $ANTLR start "rule__Panorama__Group__0"
    // InternalTourDsl.g:583:1: rule__Panorama__Group__0 : rule__Panorama__Group__0__Impl rule__Panorama__Group__1 ;
    public final void rule__Panorama__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:587:1: ( rule__Panorama__Group__0__Impl rule__Panorama__Group__1 )
            // InternalTourDsl.g:588:2: rule__Panorama__Group__0__Impl rule__Panorama__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Panorama__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__0"


    // $ANTLR start "rule__Panorama__Group__0__Impl"
    // InternalTourDsl.g:595:1: rule__Panorama__Group__0__Impl : ( () ) ;
    public final void rule__Panorama__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:599:1: ( ( () ) )
            // InternalTourDsl.g:600:1: ( () )
            {
            // InternalTourDsl.g:600:1: ( () )
            // InternalTourDsl.g:601:2: ()
            {
             before(grammarAccess.getPanoramaAccess().getPanoramaAction_0()); 
            // InternalTourDsl.g:602:2: ()
            // InternalTourDsl.g:602:3: 
            {
            }

             after(grammarAccess.getPanoramaAccess().getPanoramaAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__0__Impl"


    // $ANTLR start "rule__Panorama__Group__1"
    // InternalTourDsl.g:610:1: rule__Panorama__Group__1 : rule__Panorama__Group__1__Impl rule__Panorama__Group__2 ;
    public final void rule__Panorama__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:614:1: ( rule__Panorama__Group__1__Impl rule__Panorama__Group__2 )
            // InternalTourDsl.g:615:2: rule__Panorama__Group__1__Impl rule__Panorama__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Panorama__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__1"


    // $ANTLR start "rule__Panorama__Group__1__Impl"
    // InternalTourDsl.g:622:1: rule__Panorama__Group__1__Impl : ( RULE_LBRACKET ) ;
    public final void rule__Panorama__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:626:1: ( ( RULE_LBRACKET ) )
            // InternalTourDsl.g:627:1: ( RULE_LBRACKET )
            {
            // InternalTourDsl.g:627:1: ( RULE_LBRACKET )
            // InternalTourDsl.g:628:2: RULE_LBRACKET
            {
             before(grammarAccess.getPanoramaAccess().getLBRACKETTerminalRuleCall_1()); 
            match(input,RULE_LBRACKET,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getLBRACKETTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__1__Impl"


    // $ANTLR start "rule__Panorama__Group__2"
    // InternalTourDsl.g:637:1: rule__Panorama__Group__2 : rule__Panorama__Group__2__Impl rule__Panorama__Group__3 ;
    public final void rule__Panorama__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:641:1: ( rule__Panorama__Group__2__Impl rule__Panorama__Group__3 )
            // InternalTourDsl.g:642:2: rule__Panorama__Group__2__Impl rule__Panorama__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Panorama__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__2"


    // $ANTLR start "rule__Panorama__Group__2__Impl"
    // InternalTourDsl.g:649:1: rule__Panorama__Group__2__Impl : ( RULE_NAME ) ;
    public final void rule__Panorama__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:653:1: ( ( RULE_NAME ) )
            // InternalTourDsl.g:654:1: ( RULE_NAME )
            {
            // InternalTourDsl.g:654:1: ( RULE_NAME )
            // InternalTourDsl.g:655:2: RULE_NAME
            {
             before(grammarAccess.getPanoramaAccess().getNAMETerminalRuleCall_2()); 
            match(input,RULE_NAME,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getNAMETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__2__Impl"


    // $ANTLR start "rule__Panorama__Group__3"
    // InternalTourDsl.g:664:1: rule__Panorama__Group__3 : rule__Panorama__Group__3__Impl rule__Panorama__Group__4 ;
    public final void rule__Panorama__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:668:1: ( rule__Panorama__Group__3__Impl rule__Panorama__Group__4 )
            // InternalTourDsl.g:669:2: rule__Panorama__Group__3__Impl rule__Panorama__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Panorama__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__3"


    // $ANTLR start "rule__Panorama__Group__3__Impl"
    // InternalTourDsl.g:676:1: rule__Panorama__Group__3__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Panorama__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:680:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:681:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:681:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:682:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_3()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__3__Impl"


    // $ANTLR start "rule__Panorama__Group__4"
    // InternalTourDsl.g:691:1: rule__Panorama__Group__4 : rule__Panorama__Group__4__Impl rule__Panorama__Group__5 ;
    public final void rule__Panorama__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:695:1: ( rule__Panorama__Group__4__Impl rule__Panorama__Group__5 )
            // InternalTourDsl.g:696:2: rule__Panorama__Group__4__Impl rule__Panorama__Group__5
            {
            pushFollow(FOLLOW_7);
            rule__Panorama__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__4"


    // $ANTLR start "rule__Panorama__Group__4__Impl"
    // InternalTourDsl.g:703:1: rule__Panorama__Group__4__Impl : ( ( rule__Panorama__NombreAssignment_4 ) ) ;
    public final void rule__Panorama__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:707:1: ( ( ( rule__Panorama__NombreAssignment_4 ) ) )
            // InternalTourDsl.g:708:1: ( ( rule__Panorama__NombreAssignment_4 ) )
            {
            // InternalTourDsl.g:708:1: ( ( rule__Panorama__NombreAssignment_4 ) )
            // InternalTourDsl.g:709:2: ( rule__Panorama__NombreAssignment_4 )
            {
             before(grammarAccess.getPanoramaAccess().getNombreAssignment_4()); 
            // InternalTourDsl.g:710:2: ( rule__Panorama__NombreAssignment_4 )
            // InternalTourDsl.g:710:3: rule__Panorama__NombreAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Panorama__NombreAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getPanoramaAccess().getNombreAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__4__Impl"


    // $ANTLR start "rule__Panorama__Group__5"
    // InternalTourDsl.g:718:1: rule__Panorama__Group__5 : rule__Panorama__Group__5__Impl rule__Panorama__Group__6 ;
    public final void rule__Panorama__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:722:1: ( rule__Panorama__Group__5__Impl rule__Panorama__Group__6 )
            // InternalTourDsl.g:723:2: rule__Panorama__Group__5__Impl rule__Panorama__Group__6
            {
            pushFollow(FOLLOW_13);
            rule__Panorama__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__5"


    // $ANTLR start "rule__Panorama__Group__5__Impl"
    // InternalTourDsl.g:730:1: rule__Panorama__Group__5__Impl : ( RULE_COMA ) ;
    public final void rule__Panorama__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:734:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:735:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:735:1: ( RULE_COMA )
            // InternalTourDsl.g:736:2: RULE_COMA
            {
             before(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_5()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__5__Impl"


    // $ANTLR start "rule__Panorama__Group__6"
    // InternalTourDsl.g:745:1: rule__Panorama__Group__6 : rule__Panorama__Group__6__Impl rule__Panorama__Group__7 ;
    public final void rule__Panorama__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:749:1: ( rule__Panorama__Group__6__Impl rule__Panorama__Group__7 )
            // InternalTourDsl.g:750:2: rule__Panorama__Group__6__Impl rule__Panorama__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__Panorama__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__6"


    // $ANTLR start "rule__Panorama__Group__6__Impl"
    // InternalTourDsl.g:757:1: rule__Panorama__Group__6__Impl : ( RULE_DESCRIPTION ) ;
    public final void rule__Panorama__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:761:1: ( ( RULE_DESCRIPTION ) )
            // InternalTourDsl.g:762:1: ( RULE_DESCRIPTION )
            {
            // InternalTourDsl.g:762:1: ( RULE_DESCRIPTION )
            // InternalTourDsl.g:763:2: RULE_DESCRIPTION
            {
             before(grammarAccess.getPanoramaAccess().getDESCRIPTIONTerminalRuleCall_6()); 
            match(input,RULE_DESCRIPTION,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getDESCRIPTIONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__6__Impl"


    // $ANTLR start "rule__Panorama__Group__7"
    // InternalTourDsl.g:772:1: rule__Panorama__Group__7 : rule__Panorama__Group__7__Impl rule__Panorama__Group__8 ;
    public final void rule__Panorama__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:776:1: ( rule__Panorama__Group__7__Impl rule__Panorama__Group__8 )
            // InternalTourDsl.g:777:2: rule__Panorama__Group__7__Impl rule__Panorama__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__Panorama__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__7"


    // $ANTLR start "rule__Panorama__Group__7__Impl"
    // InternalTourDsl.g:784:1: rule__Panorama__Group__7__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Panorama__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:788:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:789:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:789:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:790:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_7()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__7__Impl"


    // $ANTLR start "rule__Panorama__Group__8"
    // InternalTourDsl.g:799:1: rule__Panorama__Group__8 : rule__Panorama__Group__8__Impl rule__Panorama__Group__9 ;
    public final void rule__Panorama__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:803:1: ( rule__Panorama__Group__8__Impl rule__Panorama__Group__9 )
            // InternalTourDsl.g:804:2: rule__Panorama__Group__8__Impl rule__Panorama__Group__9
            {
            pushFollow(FOLLOW_7);
            rule__Panorama__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__8"


    // $ANTLR start "rule__Panorama__Group__8__Impl"
    // InternalTourDsl.g:811:1: rule__Panorama__Group__8__Impl : ( ( rule__Panorama__NombreAssignment_8 ) ) ;
    public final void rule__Panorama__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:815:1: ( ( ( rule__Panorama__NombreAssignment_8 ) ) )
            // InternalTourDsl.g:816:1: ( ( rule__Panorama__NombreAssignment_8 ) )
            {
            // InternalTourDsl.g:816:1: ( ( rule__Panorama__NombreAssignment_8 ) )
            // InternalTourDsl.g:817:2: ( rule__Panorama__NombreAssignment_8 )
            {
             before(grammarAccess.getPanoramaAccess().getNombreAssignment_8()); 
            // InternalTourDsl.g:818:2: ( rule__Panorama__NombreAssignment_8 )
            // InternalTourDsl.g:818:3: rule__Panorama__NombreAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Panorama__NombreAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getPanoramaAccess().getNombreAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__8__Impl"


    // $ANTLR start "rule__Panorama__Group__9"
    // InternalTourDsl.g:826:1: rule__Panorama__Group__9 : rule__Panorama__Group__9__Impl rule__Panorama__Group__10 ;
    public final void rule__Panorama__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:830:1: ( rule__Panorama__Group__9__Impl rule__Panorama__Group__10 )
            // InternalTourDsl.g:831:2: rule__Panorama__Group__9__Impl rule__Panorama__Group__10
            {
            pushFollow(FOLLOW_14);
            rule__Panorama__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__9"


    // $ANTLR start "rule__Panorama__Group__9__Impl"
    // InternalTourDsl.g:838:1: rule__Panorama__Group__9__Impl : ( RULE_COMA ) ;
    public final void rule__Panorama__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:842:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:843:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:843:1: ( RULE_COMA )
            // InternalTourDsl.g:844:2: RULE_COMA
            {
             before(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_9()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__9__Impl"


    // $ANTLR start "rule__Panorama__Group__10"
    // InternalTourDsl.g:853:1: rule__Panorama__Group__10 : rule__Panorama__Group__10__Impl rule__Panorama__Group__11 ;
    public final void rule__Panorama__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:857:1: ( rule__Panorama__Group__10__Impl rule__Panorama__Group__11 )
            // InternalTourDsl.g:858:2: rule__Panorama__Group__10__Impl rule__Panorama__Group__11
            {
            pushFollow(FOLLOW_7);
            rule__Panorama__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__10"


    // $ANTLR start "rule__Panorama__Group__10__Impl"
    // InternalTourDsl.g:865:1: rule__Panorama__Group__10__Impl : ( ( rule__Panorama__RotacionPanoramaAssignment_10 ) ) ;
    public final void rule__Panorama__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:869:1: ( ( ( rule__Panorama__RotacionPanoramaAssignment_10 ) ) )
            // InternalTourDsl.g:870:1: ( ( rule__Panorama__RotacionPanoramaAssignment_10 ) )
            {
            // InternalTourDsl.g:870:1: ( ( rule__Panorama__RotacionPanoramaAssignment_10 ) )
            // InternalTourDsl.g:871:2: ( rule__Panorama__RotacionPanoramaAssignment_10 )
            {
             before(grammarAccess.getPanoramaAccess().getRotacionPanoramaAssignment_10()); 
            // InternalTourDsl.g:872:2: ( rule__Panorama__RotacionPanoramaAssignment_10 )
            // InternalTourDsl.g:872:3: rule__Panorama__RotacionPanoramaAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__Panorama__RotacionPanoramaAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getPanoramaAccess().getRotacionPanoramaAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__10__Impl"


    // $ANTLR start "rule__Panorama__Group__11"
    // InternalTourDsl.g:880:1: rule__Panorama__Group__11 : rule__Panorama__Group__11__Impl rule__Panorama__Group__12 ;
    public final void rule__Panorama__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:884:1: ( rule__Panorama__Group__11__Impl rule__Panorama__Group__12 )
            // InternalTourDsl.g:885:2: rule__Panorama__Group__11__Impl rule__Panorama__Group__12
            {
            pushFollow(FOLLOW_15);
            rule__Panorama__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__11"


    // $ANTLR start "rule__Panorama__Group__11__Impl"
    // InternalTourDsl.g:892:1: rule__Panorama__Group__11__Impl : ( RULE_COMA ) ;
    public final void rule__Panorama__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:896:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:897:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:897:1: ( RULE_COMA )
            // InternalTourDsl.g:898:2: RULE_COMA
            {
             before(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_11()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__11__Impl"


    // $ANTLR start "rule__Panorama__Group__12"
    // InternalTourDsl.g:907:1: rule__Panorama__Group__12 : rule__Panorama__Group__12__Impl rule__Panorama__Group__13 ;
    public final void rule__Panorama__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:911:1: ( rule__Panorama__Group__12__Impl rule__Panorama__Group__13 )
            // InternalTourDsl.g:912:2: rule__Panorama__Group__12__Impl rule__Panorama__Group__13
            {
            pushFollow(FOLLOW_5);
            rule__Panorama__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__12"


    // $ANTLR start "rule__Panorama__Group__12__Impl"
    // InternalTourDsl.g:919:1: rule__Panorama__Group__12__Impl : ( RULE_PATHS ) ;
    public final void rule__Panorama__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:923:1: ( ( RULE_PATHS ) )
            // InternalTourDsl.g:924:1: ( RULE_PATHS )
            {
            // InternalTourDsl.g:924:1: ( RULE_PATHS )
            // InternalTourDsl.g:925:2: RULE_PATHS
            {
             before(grammarAccess.getPanoramaAccess().getPATHSTerminalRuleCall_12()); 
            match(input,RULE_PATHS,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getPATHSTerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__12__Impl"


    // $ANTLR start "rule__Panorama__Group__13"
    // InternalTourDsl.g:934:1: rule__Panorama__Group__13 : rule__Panorama__Group__13__Impl rule__Panorama__Group__14 ;
    public final void rule__Panorama__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:938:1: ( rule__Panorama__Group__13__Impl rule__Panorama__Group__14 )
            // InternalTourDsl.g:939:2: rule__Panorama__Group__13__Impl rule__Panorama__Group__14
            {
            pushFollow(FOLLOW_9);
            rule__Panorama__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__13"


    // $ANTLR start "rule__Panorama__Group__13__Impl"
    // InternalTourDsl.g:946:1: rule__Panorama__Group__13__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Panorama__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:950:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:951:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:951:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:952:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_13()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getTWOPOINTSTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__13__Impl"


    // $ANTLR start "rule__Panorama__Group__14"
    // InternalTourDsl.g:961:1: rule__Panorama__Group__14 : rule__Panorama__Group__14__Impl rule__Panorama__Group__15 ;
    public final void rule__Panorama__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:965:1: ( rule__Panorama__Group__14__Impl rule__Panorama__Group__15 )
            // InternalTourDsl.g:966:2: rule__Panorama__Group__14__Impl rule__Panorama__Group__15
            {
            pushFollow(FOLLOW_3);
            rule__Panorama__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__14"


    // $ANTLR start "rule__Panorama__Group__14__Impl"
    // InternalTourDsl.g:973:1: rule__Panorama__Group__14__Impl : ( RULE_LPARENTISISCUADRADO ) ;
    public final void rule__Panorama__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:977:1: ( ( RULE_LPARENTISISCUADRADO ) )
            // InternalTourDsl.g:978:1: ( RULE_LPARENTISISCUADRADO )
            {
            // InternalTourDsl.g:978:1: ( RULE_LPARENTISISCUADRADO )
            // InternalTourDsl.g:979:2: RULE_LPARENTISISCUADRADO
            {
             before(grammarAccess.getPanoramaAccess().getLPARENTISISCUADRADOTerminalRuleCall_14()); 
            match(input,RULE_LPARENTISISCUADRADO,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getLPARENTISISCUADRADOTerminalRuleCall_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__14__Impl"


    // $ANTLR start "rule__Panorama__Group__15"
    // InternalTourDsl.g:988:1: rule__Panorama__Group__15 : rule__Panorama__Group__15__Impl rule__Panorama__Group__16 ;
    public final void rule__Panorama__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:992:1: ( rule__Panorama__Group__15__Impl rule__Panorama__Group__16 )
            // InternalTourDsl.g:993:2: rule__Panorama__Group__15__Impl rule__Panorama__Group__16
            {
            pushFollow(FOLLOW_16);
            rule__Panorama__Group__15__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__16();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__15"


    // $ANTLR start "rule__Panorama__Group__15__Impl"
    // InternalTourDsl.g:1000:1: rule__Panorama__Group__15__Impl : ( ( ( rule__Panorama__HotspotAssignment_15 ) ) ( ( rule__Panorama__HotspotAssignment_15 )* ) ) ;
    public final void rule__Panorama__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1004:1: ( ( ( ( rule__Panorama__HotspotAssignment_15 ) ) ( ( rule__Panorama__HotspotAssignment_15 )* ) ) )
            // InternalTourDsl.g:1005:1: ( ( ( rule__Panorama__HotspotAssignment_15 ) ) ( ( rule__Panorama__HotspotAssignment_15 )* ) )
            {
            // InternalTourDsl.g:1005:1: ( ( ( rule__Panorama__HotspotAssignment_15 ) ) ( ( rule__Panorama__HotspotAssignment_15 )* ) )
            // InternalTourDsl.g:1006:2: ( ( rule__Panorama__HotspotAssignment_15 ) ) ( ( rule__Panorama__HotspotAssignment_15 )* )
            {
            // InternalTourDsl.g:1006:2: ( ( rule__Panorama__HotspotAssignment_15 ) )
            // InternalTourDsl.g:1007:3: ( rule__Panorama__HotspotAssignment_15 )
            {
             before(grammarAccess.getPanoramaAccess().getHotspotAssignment_15()); 
            // InternalTourDsl.g:1008:3: ( rule__Panorama__HotspotAssignment_15 )
            // InternalTourDsl.g:1008:4: rule__Panorama__HotspotAssignment_15
            {
            pushFollow(FOLLOW_11);
            rule__Panorama__HotspotAssignment_15();

            state._fsp--;


            }

             after(grammarAccess.getPanoramaAccess().getHotspotAssignment_15()); 

            }

            // InternalTourDsl.g:1011:2: ( ( rule__Panorama__HotspotAssignment_15 )* )
            // InternalTourDsl.g:1012:3: ( rule__Panorama__HotspotAssignment_15 )*
            {
             before(grammarAccess.getPanoramaAccess().getHotspotAssignment_15()); 
            // InternalTourDsl.g:1013:3: ( rule__Panorama__HotspotAssignment_15 )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_LBRACKET) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalTourDsl.g:1013:4: rule__Panorama__HotspotAssignment_15
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__Panorama__HotspotAssignment_15();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

             after(grammarAccess.getPanoramaAccess().getHotspotAssignment_15()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__15__Impl"


    // $ANTLR start "rule__Panorama__Group__16"
    // InternalTourDsl.g:1022:1: rule__Panorama__Group__16 : rule__Panorama__Group__16__Impl rule__Panorama__Group__17 ;
    public final void rule__Panorama__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1026:1: ( rule__Panorama__Group__16__Impl rule__Panorama__Group__17 )
            // InternalTourDsl.g:1027:2: rule__Panorama__Group__16__Impl rule__Panorama__Group__17
            {
            pushFollow(FOLLOW_16);
            rule__Panorama__Group__16__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__17();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__16"


    // $ANTLR start "rule__Panorama__Group__16__Impl"
    // InternalTourDsl.g:1034:1: rule__Panorama__Group__16__Impl : ( ( RULE_COMA )? ) ;
    public final void rule__Panorama__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1038:1: ( ( ( RULE_COMA )? ) )
            // InternalTourDsl.g:1039:1: ( ( RULE_COMA )? )
            {
            // InternalTourDsl.g:1039:1: ( ( RULE_COMA )? )
            // InternalTourDsl.g:1040:2: ( RULE_COMA )?
            {
             before(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_16()); 
            // InternalTourDsl.g:1041:2: ( RULE_COMA )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_COMA) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalTourDsl.g:1041:3: RULE_COMA
                    {
                    match(input,RULE_COMA,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPanoramaAccess().getCOMATerminalRuleCall_16()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__16__Impl"


    // $ANTLR start "rule__Panorama__Group__17"
    // InternalTourDsl.g:1049:1: rule__Panorama__Group__17 : rule__Panorama__Group__17__Impl rule__Panorama__Group__18 ;
    public final void rule__Panorama__Group__17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1053:1: ( rule__Panorama__Group__17__Impl rule__Panorama__Group__18 )
            // InternalTourDsl.g:1054:2: rule__Panorama__Group__17__Impl rule__Panorama__Group__18
            {
            pushFollow(FOLLOW_12);
            rule__Panorama__Group__17__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Panorama__Group__18();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__17"


    // $ANTLR start "rule__Panorama__Group__17__Impl"
    // InternalTourDsl.g:1061:1: rule__Panorama__Group__17__Impl : ( RULE_RPARENTISISCUADRADO ) ;
    public final void rule__Panorama__Group__17__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1065:1: ( ( RULE_RPARENTISISCUADRADO ) )
            // InternalTourDsl.g:1066:1: ( RULE_RPARENTISISCUADRADO )
            {
            // InternalTourDsl.g:1066:1: ( RULE_RPARENTISISCUADRADO )
            // InternalTourDsl.g:1067:2: RULE_RPARENTISISCUADRADO
            {
             before(grammarAccess.getPanoramaAccess().getRPARENTISISCUADRADOTerminalRuleCall_17()); 
            match(input,RULE_RPARENTISISCUADRADO,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getRPARENTISISCUADRADOTerminalRuleCall_17()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__17__Impl"


    // $ANTLR start "rule__Panorama__Group__18"
    // InternalTourDsl.g:1076:1: rule__Panorama__Group__18 : rule__Panorama__Group__18__Impl ;
    public final void rule__Panorama__Group__18() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1080:1: ( rule__Panorama__Group__18__Impl )
            // InternalTourDsl.g:1081:2: rule__Panorama__Group__18__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Panorama__Group__18__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__18"


    // $ANTLR start "rule__Panorama__Group__18__Impl"
    // InternalTourDsl.g:1087:1: rule__Panorama__Group__18__Impl : ( RULE_RBRACKET ) ;
    public final void rule__Panorama__Group__18__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1091:1: ( ( RULE_RBRACKET ) )
            // InternalTourDsl.g:1092:1: ( RULE_RBRACKET )
            {
            // InternalTourDsl.g:1092:1: ( RULE_RBRACKET )
            // InternalTourDsl.g:1093:2: RULE_RBRACKET
            {
             before(grammarAccess.getPanoramaAccess().getRBRACKETTerminalRuleCall_18()); 
            match(input,RULE_RBRACKET,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getRBRACKETTerminalRuleCall_18()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__Group__18__Impl"


    // $ANTLR start "rule__Hotspot__Group__0"
    // InternalTourDsl.g:1103:1: rule__Hotspot__Group__0 : rule__Hotspot__Group__0__Impl rule__Hotspot__Group__1 ;
    public final void rule__Hotspot__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1107:1: ( rule__Hotspot__Group__0__Impl rule__Hotspot__Group__1 )
            // InternalTourDsl.g:1108:2: rule__Hotspot__Group__0__Impl rule__Hotspot__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Hotspot__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__0"


    // $ANTLR start "rule__Hotspot__Group__0__Impl"
    // InternalTourDsl.g:1115:1: rule__Hotspot__Group__0__Impl : ( () ) ;
    public final void rule__Hotspot__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1119:1: ( ( () ) )
            // InternalTourDsl.g:1120:1: ( () )
            {
            // InternalTourDsl.g:1120:1: ( () )
            // InternalTourDsl.g:1121:2: ()
            {
             before(grammarAccess.getHotspotAccess().getHotspotAction_0()); 
            // InternalTourDsl.g:1122:2: ()
            // InternalTourDsl.g:1122:3: 
            {
            }

             after(grammarAccess.getHotspotAccess().getHotspotAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__0__Impl"


    // $ANTLR start "rule__Hotspot__Group__1"
    // InternalTourDsl.g:1130:1: rule__Hotspot__Group__1 : rule__Hotspot__Group__1__Impl rule__Hotspot__Group__2 ;
    public final void rule__Hotspot__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1134:1: ( rule__Hotspot__Group__1__Impl rule__Hotspot__Group__2 )
            // InternalTourDsl.g:1135:2: rule__Hotspot__Group__1__Impl rule__Hotspot__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Hotspot__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__1"


    // $ANTLR start "rule__Hotspot__Group__1__Impl"
    // InternalTourDsl.g:1142:1: rule__Hotspot__Group__1__Impl : ( RULE_LBRACKET ) ;
    public final void rule__Hotspot__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1146:1: ( ( RULE_LBRACKET ) )
            // InternalTourDsl.g:1147:1: ( RULE_LBRACKET )
            {
            // InternalTourDsl.g:1147:1: ( RULE_LBRACKET )
            // InternalTourDsl.g:1148:2: RULE_LBRACKET
            {
             before(grammarAccess.getHotspotAccess().getLBRACKETTerminalRuleCall_1()); 
            match(input,RULE_LBRACKET,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getLBRACKETTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__1__Impl"


    // $ANTLR start "rule__Hotspot__Group__2"
    // InternalTourDsl.g:1157:1: rule__Hotspot__Group__2 : rule__Hotspot__Group__2__Impl rule__Hotspot__Group__3 ;
    public final void rule__Hotspot__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1161:1: ( rule__Hotspot__Group__2__Impl rule__Hotspot__Group__3 )
            // InternalTourDsl.g:1162:2: rule__Hotspot__Group__2__Impl rule__Hotspot__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Hotspot__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__2"


    // $ANTLR start "rule__Hotspot__Group__2__Impl"
    // InternalTourDsl.g:1169:1: rule__Hotspot__Group__2__Impl : ( RULE_NAME ) ;
    public final void rule__Hotspot__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1173:1: ( ( RULE_NAME ) )
            // InternalTourDsl.g:1174:1: ( RULE_NAME )
            {
            // InternalTourDsl.g:1174:1: ( RULE_NAME )
            // InternalTourDsl.g:1175:2: RULE_NAME
            {
             before(grammarAccess.getHotspotAccess().getNAMETerminalRuleCall_2()); 
            match(input,RULE_NAME,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getNAMETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__2__Impl"


    // $ANTLR start "rule__Hotspot__Group__3"
    // InternalTourDsl.g:1184:1: rule__Hotspot__Group__3 : rule__Hotspot__Group__3__Impl rule__Hotspot__Group__4 ;
    public final void rule__Hotspot__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1188:1: ( rule__Hotspot__Group__3__Impl rule__Hotspot__Group__4 )
            // InternalTourDsl.g:1189:2: rule__Hotspot__Group__3__Impl rule__Hotspot__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Hotspot__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__3"


    // $ANTLR start "rule__Hotspot__Group__3__Impl"
    // InternalTourDsl.g:1196:1: rule__Hotspot__Group__3__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Hotspot__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1200:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1201:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1201:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1202:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getHotspotAccess().getTWOPOINTSTerminalRuleCall_3()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getTWOPOINTSTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__3__Impl"


    // $ANTLR start "rule__Hotspot__Group__4"
    // InternalTourDsl.g:1211:1: rule__Hotspot__Group__4 : rule__Hotspot__Group__4__Impl rule__Hotspot__Group__5 ;
    public final void rule__Hotspot__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1215:1: ( rule__Hotspot__Group__4__Impl rule__Hotspot__Group__5 )
            // InternalTourDsl.g:1216:2: rule__Hotspot__Group__4__Impl rule__Hotspot__Group__5
            {
            pushFollow(FOLLOW_7);
            rule__Hotspot__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__4"


    // $ANTLR start "rule__Hotspot__Group__4__Impl"
    // InternalTourDsl.g:1223:1: rule__Hotspot__Group__4__Impl : ( ( rule__Hotspot__NombreAssignment_4 ) ) ;
    public final void rule__Hotspot__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1227:1: ( ( ( rule__Hotspot__NombreAssignment_4 ) ) )
            // InternalTourDsl.g:1228:1: ( ( rule__Hotspot__NombreAssignment_4 ) )
            {
            // InternalTourDsl.g:1228:1: ( ( rule__Hotspot__NombreAssignment_4 ) )
            // InternalTourDsl.g:1229:2: ( rule__Hotspot__NombreAssignment_4 )
            {
             before(grammarAccess.getHotspotAccess().getNombreAssignment_4()); 
            // InternalTourDsl.g:1230:2: ( rule__Hotspot__NombreAssignment_4 )
            // InternalTourDsl.g:1230:3: rule__Hotspot__NombreAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Hotspot__NombreAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getHotspotAccess().getNombreAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__4__Impl"


    // $ANTLR start "rule__Hotspot__Group__5"
    // InternalTourDsl.g:1238:1: rule__Hotspot__Group__5 : rule__Hotspot__Group__5__Impl rule__Hotspot__Group__6 ;
    public final void rule__Hotspot__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1242:1: ( rule__Hotspot__Group__5__Impl rule__Hotspot__Group__6 )
            // InternalTourDsl.g:1243:2: rule__Hotspot__Group__5__Impl rule__Hotspot__Group__6
            {
            pushFollow(FOLLOW_17);
            rule__Hotspot__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__5"


    // $ANTLR start "rule__Hotspot__Group__5__Impl"
    // InternalTourDsl.g:1250:1: rule__Hotspot__Group__5__Impl : ( RULE_COMA ) ;
    public final void rule__Hotspot__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1254:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:1255:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:1255:1: ( RULE_COMA )
            // InternalTourDsl.g:1256:2: RULE_COMA
            {
             before(grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_5()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__5__Impl"


    // $ANTLR start "rule__Hotspot__Group__6"
    // InternalTourDsl.g:1265:1: rule__Hotspot__Group__6 : rule__Hotspot__Group__6__Impl rule__Hotspot__Group__7 ;
    public final void rule__Hotspot__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1269:1: ( rule__Hotspot__Group__6__Impl rule__Hotspot__Group__7 )
            // InternalTourDsl.g:1270:2: rule__Hotspot__Group__6__Impl rule__Hotspot__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__Hotspot__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__6"


    // $ANTLR start "rule__Hotspot__Group__6__Impl"
    // InternalTourDsl.g:1277:1: rule__Hotspot__Group__6__Impl : ( RULE_TO ) ;
    public final void rule__Hotspot__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1281:1: ( ( RULE_TO ) )
            // InternalTourDsl.g:1282:1: ( RULE_TO )
            {
            // InternalTourDsl.g:1282:1: ( RULE_TO )
            // InternalTourDsl.g:1283:2: RULE_TO
            {
             before(grammarAccess.getHotspotAccess().getTOTerminalRuleCall_6()); 
            match(input,RULE_TO,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getTOTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__6__Impl"


    // $ANTLR start "rule__Hotspot__Group__7"
    // InternalTourDsl.g:1292:1: rule__Hotspot__Group__7 : rule__Hotspot__Group__7__Impl rule__Hotspot__Group__8 ;
    public final void rule__Hotspot__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1296:1: ( rule__Hotspot__Group__7__Impl rule__Hotspot__Group__8 )
            // InternalTourDsl.g:1297:2: rule__Hotspot__Group__7__Impl rule__Hotspot__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__Hotspot__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__7"


    // $ANTLR start "rule__Hotspot__Group__7__Impl"
    // InternalTourDsl.g:1304:1: rule__Hotspot__Group__7__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Hotspot__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1308:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1309:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1309:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1310:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getHotspotAccess().getTWOPOINTSTerminalRuleCall_7()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getTWOPOINTSTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__7__Impl"


    // $ANTLR start "rule__Hotspot__Group__8"
    // InternalTourDsl.g:1319:1: rule__Hotspot__Group__8 : rule__Hotspot__Group__8__Impl rule__Hotspot__Group__9 ;
    public final void rule__Hotspot__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1323:1: ( rule__Hotspot__Group__8__Impl rule__Hotspot__Group__9 )
            // InternalTourDsl.g:1324:2: rule__Hotspot__Group__8__Impl rule__Hotspot__Group__9
            {
            pushFollow(FOLLOW_7);
            rule__Hotspot__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__8"


    // $ANTLR start "rule__Hotspot__Group__8__Impl"
    // InternalTourDsl.g:1331:1: rule__Hotspot__Group__8__Impl : ( ( rule__Hotspot__DirigeAssignment_8 ) ) ;
    public final void rule__Hotspot__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1335:1: ( ( ( rule__Hotspot__DirigeAssignment_8 ) ) )
            // InternalTourDsl.g:1336:1: ( ( rule__Hotspot__DirigeAssignment_8 ) )
            {
            // InternalTourDsl.g:1336:1: ( ( rule__Hotspot__DirigeAssignment_8 ) )
            // InternalTourDsl.g:1337:2: ( rule__Hotspot__DirigeAssignment_8 )
            {
             before(grammarAccess.getHotspotAccess().getDirigeAssignment_8()); 
            // InternalTourDsl.g:1338:2: ( rule__Hotspot__DirigeAssignment_8 )
            // InternalTourDsl.g:1338:3: rule__Hotspot__DirigeAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Hotspot__DirigeAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getHotspotAccess().getDirigeAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__8__Impl"


    // $ANTLR start "rule__Hotspot__Group__9"
    // InternalTourDsl.g:1346:1: rule__Hotspot__Group__9 : rule__Hotspot__Group__9__Impl rule__Hotspot__Group__10 ;
    public final void rule__Hotspot__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1350:1: ( rule__Hotspot__Group__9__Impl rule__Hotspot__Group__10 )
            // InternalTourDsl.g:1351:2: rule__Hotspot__Group__9__Impl rule__Hotspot__Group__10
            {
            pushFollow(FOLLOW_18);
            rule__Hotspot__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__9"


    // $ANTLR start "rule__Hotspot__Group__9__Impl"
    // InternalTourDsl.g:1358:1: rule__Hotspot__Group__9__Impl : ( RULE_COMA ) ;
    public final void rule__Hotspot__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1362:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:1363:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:1363:1: ( RULE_COMA )
            // InternalTourDsl.g:1364:2: RULE_COMA
            {
             before(grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_9()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__9__Impl"


    // $ANTLR start "rule__Hotspot__Group__10"
    // InternalTourDsl.g:1373:1: rule__Hotspot__Group__10 : rule__Hotspot__Group__10__Impl rule__Hotspot__Group__11 ;
    public final void rule__Hotspot__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1377:1: ( rule__Hotspot__Group__10__Impl rule__Hotspot__Group__11 )
            // InternalTourDsl.g:1378:2: rule__Hotspot__Group__10__Impl rule__Hotspot__Group__11
            {
            pushFollow(FOLLOW_7);
            rule__Hotspot__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__10"


    // $ANTLR start "rule__Hotspot__Group__10__Impl"
    // InternalTourDsl.g:1385:1: rule__Hotspot__Group__10__Impl : ( ( rule__Hotspot__PosicionAssignment_10 ) ) ;
    public final void rule__Hotspot__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1389:1: ( ( ( rule__Hotspot__PosicionAssignment_10 ) ) )
            // InternalTourDsl.g:1390:1: ( ( rule__Hotspot__PosicionAssignment_10 ) )
            {
            // InternalTourDsl.g:1390:1: ( ( rule__Hotspot__PosicionAssignment_10 ) )
            // InternalTourDsl.g:1391:2: ( rule__Hotspot__PosicionAssignment_10 )
            {
             before(grammarAccess.getHotspotAccess().getPosicionAssignment_10()); 
            // InternalTourDsl.g:1392:2: ( rule__Hotspot__PosicionAssignment_10 )
            // InternalTourDsl.g:1392:3: rule__Hotspot__PosicionAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__Hotspot__PosicionAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getHotspotAccess().getPosicionAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__10__Impl"


    // $ANTLR start "rule__Hotspot__Group__11"
    // InternalTourDsl.g:1400:1: rule__Hotspot__Group__11 : rule__Hotspot__Group__11__Impl rule__Hotspot__Group__12 ;
    public final void rule__Hotspot__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1404:1: ( rule__Hotspot__Group__11__Impl rule__Hotspot__Group__12 )
            // InternalTourDsl.g:1405:2: rule__Hotspot__Group__11__Impl rule__Hotspot__Group__12
            {
            pushFollow(FOLLOW_14);
            rule__Hotspot__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__11"


    // $ANTLR start "rule__Hotspot__Group__11__Impl"
    // InternalTourDsl.g:1412:1: rule__Hotspot__Group__11__Impl : ( RULE_COMA ) ;
    public final void rule__Hotspot__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1416:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:1417:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:1417:1: ( RULE_COMA )
            // InternalTourDsl.g:1418:2: RULE_COMA
            {
             before(grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_11()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getCOMATerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__11__Impl"


    // $ANTLR start "rule__Hotspot__Group__12"
    // InternalTourDsl.g:1427:1: rule__Hotspot__Group__12 : rule__Hotspot__Group__12__Impl rule__Hotspot__Group__13 ;
    public final void rule__Hotspot__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1431:1: ( rule__Hotspot__Group__12__Impl rule__Hotspot__Group__13 )
            // InternalTourDsl.g:1432:2: rule__Hotspot__Group__12__Impl rule__Hotspot__Group__13
            {
            pushFollow(FOLLOW_12);
            rule__Hotspot__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__12"


    // $ANTLR start "rule__Hotspot__Group__12__Impl"
    // InternalTourDsl.g:1439:1: rule__Hotspot__Group__12__Impl : ( ( rule__Hotspot__RotacionAssignment_12 ) ) ;
    public final void rule__Hotspot__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1443:1: ( ( ( rule__Hotspot__RotacionAssignment_12 ) ) )
            // InternalTourDsl.g:1444:1: ( ( rule__Hotspot__RotacionAssignment_12 ) )
            {
            // InternalTourDsl.g:1444:1: ( ( rule__Hotspot__RotacionAssignment_12 ) )
            // InternalTourDsl.g:1445:2: ( rule__Hotspot__RotacionAssignment_12 )
            {
             before(grammarAccess.getHotspotAccess().getRotacionAssignment_12()); 
            // InternalTourDsl.g:1446:2: ( rule__Hotspot__RotacionAssignment_12 )
            // InternalTourDsl.g:1446:3: rule__Hotspot__RotacionAssignment_12
            {
            pushFollow(FOLLOW_2);
            rule__Hotspot__RotacionAssignment_12();

            state._fsp--;


            }

             after(grammarAccess.getHotspotAccess().getRotacionAssignment_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__12__Impl"


    // $ANTLR start "rule__Hotspot__Group__13"
    // InternalTourDsl.g:1454:1: rule__Hotspot__Group__13 : rule__Hotspot__Group__13__Impl ;
    public final void rule__Hotspot__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1458:1: ( rule__Hotspot__Group__13__Impl )
            // InternalTourDsl.g:1459:2: rule__Hotspot__Group__13__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Hotspot__Group__13__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__13"


    // $ANTLR start "rule__Hotspot__Group__13__Impl"
    // InternalTourDsl.g:1465:1: rule__Hotspot__Group__13__Impl : ( RULE_RBRACKET ) ;
    public final void rule__Hotspot__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1469:1: ( ( RULE_RBRACKET ) )
            // InternalTourDsl.g:1470:1: ( RULE_RBRACKET )
            {
            // InternalTourDsl.g:1470:1: ( RULE_RBRACKET )
            // InternalTourDsl.g:1471:2: RULE_RBRACKET
            {
             before(grammarAccess.getHotspotAccess().getRBRACKETTerminalRuleCall_13()); 
            match(input,RULE_RBRACKET,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getRBRACKETTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__Group__13__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__0"
    // InternalTourDsl.g:1481:1: rule__RotacionPanorama__Group__0 : rule__RotacionPanorama__Group__0__Impl rule__RotacionPanorama__Group__1 ;
    public final void rule__RotacionPanorama__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1485:1: ( rule__RotacionPanorama__Group__0__Impl rule__RotacionPanorama__Group__1 )
            // InternalTourDsl.g:1486:2: rule__RotacionPanorama__Group__0__Impl rule__RotacionPanorama__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__RotacionPanorama__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__0"


    // $ANTLR start "rule__RotacionPanorama__Group__0__Impl"
    // InternalTourDsl.g:1493:1: rule__RotacionPanorama__Group__0__Impl : ( () ) ;
    public final void rule__RotacionPanorama__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1497:1: ( ( () ) )
            // InternalTourDsl.g:1498:1: ( () )
            {
            // InternalTourDsl.g:1498:1: ( () )
            // InternalTourDsl.g:1499:2: ()
            {
             before(grammarAccess.getRotacionPanoramaAccess().getRotPanoramaAction_0()); 
            // InternalTourDsl.g:1500:2: ()
            // InternalTourDsl.g:1500:3: 
            {
            }

             after(grammarAccess.getRotacionPanoramaAccess().getRotPanoramaAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__0__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__1"
    // InternalTourDsl.g:1508:1: rule__RotacionPanorama__Group__1 : rule__RotacionPanorama__Group__1__Impl rule__RotacionPanorama__Group__2 ;
    public final void rule__RotacionPanorama__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1512:1: ( rule__RotacionPanorama__Group__1__Impl rule__RotacionPanorama__Group__2 )
            // InternalTourDsl.g:1513:2: rule__RotacionPanorama__Group__1__Impl rule__RotacionPanorama__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__RotacionPanorama__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__1"


    // $ANTLR start "rule__RotacionPanorama__Group__1__Impl"
    // InternalTourDsl.g:1520:1: rule__RotacionPanorama__Group__1__Impl : ( RULE_ROTATION ) ;
    public final void rule__RotacionPanorama__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1524:1: ( ( RULE_ROTATION ) )
            // InternalTourDsl.g:1525:1: ( RULE_ROTATION )
            {
            // InternalTourDsl.g:1525:1: ( RULE_ROTATION )
            // InternalTourDsl.g:1526:2: RULE_ROTATION
            {
             before(grammarAccess.getRotacionPanoramaAccess().getROTATIONTerminalRuleCall_1()); 
            match(input,RULE_ROTATION,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getROTATIONTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__1__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__2"
    // InternalTourDsl.g:1535:1: rule__RotacionPanorama__Group__2 : rule__RotacionPanorama__Group__2__Impl rule__RotacionPanorama__Group__3 ;
    public final void rule__RotacionPanorama__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1539:1: ( rule__RotacionPanorama__Group__2__Impl rule__RotacionPanorama__Group__3 )
            // InternalTourDsl.g:1540:2: rule__RotacionPanorama__Group__2__Impl rule__RotacionPanorama__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__RotacionPanorama__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__2"


    // $ANTLR start "rule__RotacionPanorama__Group__2__Impl"
    // InternalTourDsl.g:1547:1: rule__RotacionPanorama__Group__2__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__RotacionPanorama__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1551:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1552:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1552:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1553:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_2()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__2__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__3"
    // InternalTourDsl.g:1562:1: rule__RotacionPanorama__Group__3 : rule__RotacionPanorama__Group__3__Impl rule__RotacionPanorama__Group__4 ;
    public final void rule__RotacionPanorama__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1566:1: ( rule__RotacionPanorama__Group__3__Impl rule__RotacionPanorama__Group__4 )
            // InternalTourDsl.g:1567:2: rule__RotacionPanorama__Group__3__Impl rule__RotacionPanorama__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__RotacionPanorama__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__3"


    // $ANTLR start "rule__RotacionPanorama__Group__3__Impl"
    // InternalTourDsl.g:1574:1: rule__RotacionPanorama__Group__3__Impl : ( RULE_LBRACKET ) ;
    public final void rule__RotacionPanorama__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1578:1: ( ( RULE_LBRACKET ) )
            // InternalTourDsl.g:1579:1: ( RULE_LBRACKET )
            {
            // InternalTourDsl.g:1579:1: ( RULE_LBRACKET )
            // InternalTourDsl.g:1580:2: RULE_LBRACKET
            {
             before(grammarAccess.getRotacionPanoramaAccess().getLBRACKETTerminalRuleCall_3()); 
            match(input,RULE_LBRACKET,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getLBRACKETTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__3__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__4"
    // InternalTourDsl.g:1589:1: rule__RotacionPanorama__Group__4 : rule__RotacionPanorama__Group__4__Impl rule__RotacionPanorama__Group__5 ;
    public final void rule__RotacionPanorama__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1593:1: ( rule__RotacionPanorama__Group__4__Impl rule__RotacionPanorama__Group__5 )
            // InternalTourDsl.g:1594:2: rule__RotacionPanorama__Group__4__Impl rule__RotacionPanorama__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__RotacionPanorama__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__4"


    // $ANTLR start "rule__RotacionPanorama__Group__4__Impl"
    // InternalTourDsl.g:1601:1: rule__RotacionPanorama__Group__4__Impl : ( RULE_ROTX ) ;
    public final void rule__RotacionPanorama__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1605:1: ( ( RULE_ROTX ) )
            // InternalTourDsl.g:1606:1: ( RULE_ROTX )
            {
            // InternalTourDsl.g:1606:1: ( RULE_ROTX )
            // InternalTourDsl.g:1607:2: RULE_ROTX
            {
             before(grammarAccess.getRotacionPanoramaAccess().getROTXTerminalRuleCall_4()); 
            match(input,RULE_ROTX,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getROTXTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__4__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__5"
    // InternalTourDsl.g:1616:1: rule__RotacionPanorama__Group__5 : rule__RotacionPanorama__Group__5__Impl rule__RotacionPanorama__Group__6 ;
    public final void rule__RotacionPanorama__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1620:1: ( rule__RotacionPanorama__Group__5__Impl rule__RotacionPanorama__Group__6 )
            // InternalTourDsl.g:1621:2: rule__RotacionPanorama__Group__5__Impl rule__RotacionPanorama__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__RotacionPanorama__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__5"


    // $ANTLR start "rule__RotacionPanorama__Group__5__Impl"
    // InternalTourDsl.g:1628:1: rule__RotacionPanorama__Group__5__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__RotacionPanorama__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1632:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1633:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1633:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1634:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_5()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__5__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__6"
    // InternalTourDsl.g:1643:1: rule__RotacionPanorama__Group__6 : rule__RotacionPanorama__Group__6__Impl rule__RotacionPanorama__Group__7 ;
    public final void rule__RotacionPanorama__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1647:1: ( rule__RotacionPanorama__Group__6__Impl rule__RotacionPanorama__Group__7 )
            // InternalTourDsl.g:1648:2: rule__RotacionPanorama__Group__6__Impl rule__RotacionPanorama__Group__7
            {
            pushFollow(FOLLOW_20);
            rule__RotacionPanorama__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__6"


    // $ANTLR start "rule__RotacionPanorama__Group__6__Impl"
    // InternalTourDsl.g:1655:1: rule__RotacionPanorama__Group__6__Impl : ( ( rule__RotacionPanorama__XAssignment_6 )? ) ;
    public final void rule__RotacionPanorama__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1659:1: ( ( ( rule__RotacionPanorama__XAssignment_6 )? ) )
            // InternalTourDsl.g:1660:1: ( ( rule__RotacionPanorama__XAssignment_6 )? )
            {
            // InternalTourDsl.g:1660:1: ( ( rule__RotacionPanorama__XAssignment_6 )? )
            // InternalTourDsl.g:1661:2: ( rule__RotacionPanorama__XAssignment_6 )?
            {
             before(grammarAccess.getRotacionPanoramaAccess().getXAssignment_6()); 
            // InternalTourDsl.g:1662:2: ( rule__RotacionPanorama__XAssignment_6 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_INT) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalTourDsl.g:1662:3: rule__RotacionPanorama__XAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__RotacionPanorama__XAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRotacionPanoramaAccess().getXAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__6__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__7"
    // InternalTourDsl.g:1670:1: rule__RotacionPanorama__Group__7 : rule__RotacionPanorama__Group__7__Impl rule__RotacionPanorama__Group__8 ;
    public final void rule__RotacionPanorama__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1674:1: ( rule__RotacionPanorama__Group__7__Impl rule__RotacionPanorama__Group__8 )
            // InternalTourDsl.g:1675:2: rule__RotacionPanorama__Group__7__Impl rule__RotacionPanorama__Group__8
            {
            pushFollow(FOLLOW_21);
            rule__RotacionPanorama__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__7"


    // $ANTLR start "rule__RotacionPanorama__Group__7__Impl"
    // InternalTourDsl.g:1682:1: rule__RotacionPanorama__Group__7__Impl : ( RULE_COMA ) ;
    public final void rule__RotacionPanorama__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1686:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:1687:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:1687:1: ( RULE_COMA )
            // InternalTourDsl.g:1688:2: RULE_COMA
            {
             before(grammarAccess.getRotacionPanoramaAccess().getCOMATerminalRuleCall_7()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getCOMATerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__7__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__8"
    // InternalTourDsl.g:1697:1: rule__RotacionPanorama__Group__8 : rule__RotacionPanorama__Group__8__Impl rule__RotacionPanorama__Group__9 ;
    public final void rule__RotacionPanorama__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1701:1: ( rule__RotacionPanorama__Group__8__Impl rule__RotacionPanorama__Group__9 )
            // InternalTourDsl.g:1702:2: rule__RotacionPanorama__Group__8__Impl rule__RotacionPanorama__Group__9
            {
            pushFollow(FOLLOW_5);
            rule__RotacionPanorama__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__8"


    // $ANTLR start "rule__RotacionPanorama__Group__8__Impl"
    // InternalTourDsl.g:1709:1: rule__RotacionPanorama__Group__8__Impl : ( RULE_ROTY ) ;
    public final void rule__RotacionPanorama__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1713:1: ( ( RULE_ROTY ) )
            // InternalTourDsl.g:1714:1: ( RULE_ROTY )
            {
            // InternalTourDsl.g:1714:1: ( RULE_ROTY )
            // InternalTourDsl.g:1715:2: RULE_ROTY
            {
             before(grammarAccess.getRotacionPanoramaAccess().getROTYTerminalRuleCall_8()); 
            match(input,RULE_ROTY,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getROTYTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__8__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__9"
    // InternalTourDsl.g:1724:1: rule__RotacionPanorama__Group__9 : rule__RotacionPanorama__Group__9__Impl rule__RotacionPanorama__Group__10 ;
    public final void rule__RotacionPanorama__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1728:1: ( rule__RotacionPanorama__Group__9__Impl rule__RotacionPanorama__Group__10 )
            // InternalTourDsl.g:1729:2: rule__RotacionPanorama__Group__9__Impl rule__RotacionPanorama__Group__10
            {
            pushFollow(FOLLOW_20);
            rule__RotacionPanorama__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__9"


    // $ANTLR start "rule__RotacionPanorama__Group__9__Impl"
    // InternalTourDsl.g:1736:1: rule__RotacionPanorama__Group__9__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__RotacionPanorama__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1740:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1741:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1741:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1742:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_9()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__9__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__10"
    // InternalTourDsl.g:1751:1: rule__RotacionPanorama__Group__10 : rule__RotacionPanorama__Group__10__Impl rule__RotacionPanorama__Group__11 ;
    public final void rule__RotacionPanorama__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1755:1: ( rule__RotacionPanorama__Group__10__Impl rule__RotacionPanorama__Group__11 )
            // InternalTourDsl.g:1756:2: rule__RotacionPanorama__Group__10__Impl rule__RotacionPanorama__Group__11
            {
            pushFollow(FOLLOW_20);
            rule__RotacionPanorama__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__10"


    // $ANTLR start "rule__RotacionPanorama__Group__10__Impl"
    // InternalTourDsl.g:1763:1: rule__RotacionPanorama__Group__10__Impl : ( ( rule__RotacionPanorama__YAssignment_10 )? ) ;
    public final void rule__RotacionPanorama__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1767:1: ( ( ( rule__RotacionPanorama__YAssignment_10 )? ) )
            // InternalTourDsl.g:1768:1: ( ( rule__RotacionPanorama__YAssignment_10 )? )
            {
            // InternalTourDsl.g:1768:1: ( ( rule__RotacionPanorama__YAssignment_10 )? )
            // InternalTourDsl.g:1769:2: ( rule__RotacionPanorama__YAssignment_10 )?
            {
             before(grammarAccess.getRotacionPanoramaAccess().getYAssignment_10()); 
            // InternalTourDsl.g:1770:2: ( rule__RotacionPanorama__YAssignment_10 )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_INT) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalTourDsl.g:1770:3: rule__RotacionPanorama__YAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__RotacionPanorama__YAssignment_10();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRotacionPanoramaAccess().getYAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__10__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__11"
    // InternalTourDsl.g:1778:1: rule__RotacionPanorama__Group__11 : rule__RotacionPanorama__Group__11__Impl rule__RotacionPanorama__Group__12 ;
    public final void rule__RotacionPanorama__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1782:1: ( rule__RotacionPanorama__Group__11__Impl rule__RotacionPanorama__Group__12 )
            // InternalTourDsl.g:1783:2: rule__RotacionPanorama__Group__11__Impl rule__RotacionPanorama__Group__12
            {
            pushFollow(FOLLOW_22);
            rule__RotacionPanorama__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__11"


    // $ANTLR start "rule__RotacionPanorama__Group__11__Impl"
    // InternalTourDsl.g:1790:1: rule__RotacionPanorama__Group__11__Impl : ( RULE_COMA ) ;
    public final void rule__RotacionPanorama__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1794:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:1795:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:1795:1: ( RULE_COMA )
            // InternalTourDsl.g:1796:2: RULE_COMA
            {
             before(grammarAccess.getRotacionPanoramaAccess().getCOMATerminalRuleCall_11()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getCOMATerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__11__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__12"
    // InternalTourDsl.g:1805:1: rule__RotacionPanorama__Group__12 : rule__RotacionPanorama__Group__12__Impl rule__RotacionPanorama__Group__13 ;
    public final void rule__RotacionPanorama__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1809:1: ( rule__RotacionPanorama__Group__12__Impl rule__RotacionPanorama__Group__13 )
            // InternalTourDsl.g:1810:2: rule__RotacionPanorama__Group__12__Impl rule__RotacionPanorama__Group__13
            {
            pushFollow(FOLLOW_5);
            rule__RotacionPanorama__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__12"


    // $ANTLR start "rule__RotacionPanorama__Group__12__Impl"
    // InternalTourDsl.g:1817:1: rule__RotacionPanorama__Group__12__Impl : ( RULE_ROTZ ) ;
    public final void rule__RotacionPanorama__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1821:1: ( ( RULE_ROTZ ) )
            // InternalTourDsl.g:1822:1: ( RULE_ROTZ )
            {
            // InternalTourDsl.g:1822:1: ( RULE_ROTZ )
            // InternalTourDsl.g:1823:2: RULE_ROTZ
            {
             before(grammarAccess.getRotacionPanoramaAccess().getROTZTerminalRuleCall_12()); 
            match(input,RULE_ROTZ,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getROTZTerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__12__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__13"
    // InternalTourDsl.g:1832:1: rule__RotacionPanorama__Group__13 : rule__RotacionPanorama__Group__13__Impl rule__RotacionPanorama__Group__14 ;
    public final void rule__RotacionPanorama__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1836:1: ( rule__RotacionPanorama__Group__13__Impl rule__RotacionPanorama__Group__14 )
            // InternalTourDsl.g:1837:2: rule__RotacionPanorama__Group__13__Impl rule__RotacionPanorama__Group__14
            {
            pushFollow(FOLLOW_23);
            rule__RotacionPanorama__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__13"


    // $ANTLR start "rule__RotacionPanorama__Group__13__Impl"
    // InternalTourDsl.g:1844:1: rule__RotacionPanorama__Group__13__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__RotacionPanorama__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1848:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1849:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1849:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1850:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_13()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getTWOPOINTSTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__13__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__14"
    // InternalTourDsl.g:1859:1: rule__RotacionPanorama__Group__14 : rule__RotacionPanorama__Group__14__Impl rule__RotacionPanorama__Group__15 ;
    public final void rule__RotacionPanorama__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1863:1: ( rule__RotacionPanorama__Group__14__Impl rule__RotacionPanorama__Group__15 )
            // InternalTourDsl.g:1864:2: rule__RotacionPanorama__Group__14__Impl rule__RotacionPanorama__Group__15
            {
            pushFollow(FOLLOW_23);
            rule__RotacionPanorama__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__14"


    // $ANTLR start "rule__RotacionPanorama__Group__14__Impl"
    // InternalTourDsl.g:1871:1: rule__RotacionPanorama__Group__14__Impl : ( ( rule__RotacionPanorama__ZAssignment_14 )? ) ;
    public final void rule__RotacionPanorama__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1875:1: ( ( ( rule__RotacionPanorama__ZAssignment_14 )? ) )
            // InternalTourDsl.g:1876:1: ( ( rule__RotacionPanorama__ZAssignment_14 )? )
            {
            // InternalTourDsl.g:1876:1: ( ( rule__RotacionPanorama__ZAssignment_14 )? )
            // InternalTourDsl.g:1877:2: ( rule__RotacionPanorama__ZAssignment_14 )?
            {
             before(grammarAccess.getRotacionPanoramaAccess().getZAssignment_14()); 
            // InternalTourDsl.g:1878:2: ( rule__RotacionPanorama__ZAssignment_14 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_INT) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalTourDsl.g:1878:3: rule__RotacionPanorama__ZAssignment_14
                    {
                    pushFollow(FOLLOW_2);
                    rule__RotacionPanorama__ZAssignment_14();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRotacionPanoramaAccess().getZAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__14__Impl"


    // $ANTLR start "rule__RotacionPanorama__Group__15"
    // InternalTourDsl.g:1886:1: rule__RotacionPanorama__Group__15 : rule__RotacionPanorama__Group__15__Impl ;
    public final void rule__RotacionPanorama__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1890:1: ( rule__RotacionPanorama__Group__15__Impl )
            // InternalTourDsl.g:1891:2: rule__RotacionPanorama__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RotacionPanorama__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__15"


    // $ANTLR start "rule__RotacionPanorama__Group__15__Impl"
    // InternalTourDsl.g:1897:1: rule__RotacionPanorama__Group__15__Impl : ( RULE_RBRACKET ) ;
    public final void rule__RotacionPanorama__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1901:1: ( ( RULE_RBRACKET ) )
            // InternalTourDsl.g:1902:1: ( RULE_RBRACKET )
            {
            // InternalTourDsl.g:1902:1: ( RULE_RBRACKET )
            // InternalTourDsl.g:1903:2: RULE_RBRACKET
            {
             before(grammarAccess.getRotacionPanoramaAccess().getRBRACKETTerminalRuleCall_15()); 
            match(input,RULE_RBRACKET,FOLLOW_2); 
             after(grammarAccess.getRotacionPanoramaAccess().getRBRACKETTerminalRuleCall_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__Group__15__Impl"


    // $ANTLR start "rule__Rotacion__Group__0"
    // InternalTourDsl.g:1913:1: rule__Rotacion__Group__0 : rule__Rotacion__Group__0__Impl rule__Rotacion__Group__1 ;
    public final void rule__Rotacion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1917:1: ( rule__Rotacion__Group__0__Impl rule__Rotacion__Group__1 )
            // InternalTourDsl.g:1918:2: rule__Rotacion__Group__0__Impl rule__Rotacion__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__Rotacion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__0"


    // $ANTLR start "rule__Rotacion__Group__0__Impl"
    // InternalTourDsl.g:1925:1: rule__Rotacion__Group__0__Impl : ( () ) ;
    public final void rule__Rotacion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1929:1: ( ( () ) )
            // InternalTourDsl.g:1930:1: ( () )
            {
            // InternalTourDsl.g:1930:1: ( () )
            // InternalTourDsl.g:1931:2: ()
            {
             before(grammarAccess.getRotacionAccess().getRotacionAction_0()); 
            // InternalTourDsl.g:1932:2: ()
            // InternalTourDsl.g:1932:3: 
            {
            }

             after(grammarAccess.getRotacionAccess().getRotacionAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__0__Impl"


    // $ANTLR start "rule__Rotacion__Group__1"
    // InternalTourDsl.g:1940:1: rule__Rotacion__Group__1 : rule__Rotacion__Group__1__Impl rule__Rotacion__Group__2 ;
    public final void rule__Rotacion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1944:1: ( rule__Rotacion__Group__1__Impl rule__Rotacion__Group__2 )
            // InternalTourDsl.g:1945:2: rule__Rotacion__Group__1__Impl rule__Rotacion__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Rotacion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__1"


    // $ANTLR start "rule__Rotacion__Group__1__Impl"
    // InternalTourDsl.g:1952:1: rule__Rotacion__Group__1__Impl : ( RULE_ROTATION ) ;
    public final void rule__Rotacion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1956:1: ( ( RULE_ROTATION ) )
            // InternalTourDsl.g:1957:1: ( RULE_ROTATION )
            {
            // InternalTourDsl.g:1957:1: ( RULE_ROTATION )
            // InternalTourDsl.g:1958:2: RULE_ROTATION
            {
             before(grammarAccess.getRotacionAccess().getROTATIONTerminalRuleCall_1()); 
            match(input,RULE_ROTATION,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getROTATIONTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__1__Impl"


    // $ANTLR start "rule__Rotacion__Group__2"
    // InternalTourDsl.g:1967:1: rule__Rotacion__Group__2 : rule__Rotacion__Group__2__Impl rule__Rotacion__Group__3 ;
    public final void rule__Rotacion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1971:1: ( rule__Rotacion__Group__2__Impl rule__Rotacion__Group__3 )
            // InternalTourDsl.g:1972:2: rule__Rotacion__Group__2__Impl rule__Rotacion__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__Rotacion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__2"


    // $ANTLR start "rule__Rotacion__Group__2__Impl"
    // InternalTourDsl.g:1979:1: rule__Rotacion__Group__2__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Rotacion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1983:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:1984:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:1984:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:1985:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_2()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__2__Impl"


    // $ANTLR start "rule__Rotacion__Group__3"
    // InternalTourDsl.g:1994:1: rule__Rotacion__Group__3 : rule__Rotacion__Group__3__Impl rule__Rotacion__Group__4 ;
    public final void rule__Rotacion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:1998:1: ( rule__Rotacion__Group__3__Impl rule__Rotacion__Group__4 )
            // InternalTourDsl.g:1999:2: rule__Rotacion__Group__3__Impl rule__Rotacion__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Rotacion__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__3"


    // $ANTLR start "rule__Rotacion__Group__3__Impl"
    // InternalTourDsl.g:2006:1: rule__Rotacion__Group__3__Impl : ( RULE_LBRACKET ) ;
    public final void rule__Rotacion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2010:1: ( ( RULE_LBRACKET ) )
            // InternalTourDsl.g:2011:1: ( RULE_LBRACKET )
            {
            // InternalTourDsl.g:2011:1: ( RULE_LBRACKET )
            // InternalTourDsl.g:2012:2: RULE_LBRACKET
            {
             before(grammarAccess.getRotacionAccess().getLBRACKETTerminalRuleCall_3()); 
            match(input,RULE_LBRACKET,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getLBRACKETTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__3__Impl"


    // $ANTLR start "rule__Rotacion__Group__4"
    // InternalTourDsl.g:2021:1: rule__Rotacion__Group__4 : rule__Rotacion__Group__4__Impl rule__Rotacion__Group__5 ;
    public final void rule__Rotacion__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2025:1: ( rule__Rotacion__Group__4__Impl rule__Rotacion__Group__5 )
            // InternalTourDsl.g:2026:2: rule__Rotacion__Group__4__Impl rule__Rotacion__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Rotacion__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__4"


    // $ANTLR start "rule__Rotacion__Group__4__Impl"
    // InternalTourDsl.g:2033:1: rule__Rotacion__Group__4__Impl : ( RULE_ROTX ) ;
    public final void rule__Rotacion__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2037:1: ( ( RULE_ROTX ) )
            // InternalTourDsl.g:2038:1: ( RULE_ROTX )
            {
            // InternalTourDsl.g:2038:1: ( RULE_ROTX )
            // InternalTourDsl.g:2039:2: RULE_ROTX
            {
             before(grammarAccess.getRotacionAccess().getROTXTerminalRuleCall_4()); 
            match(input,RULE_ROTX,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getROTXTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__4__Impl"


    // $ANTLR start "rule__Rotacion__Group__5"
    // InternalTourDsl.g:2048:1: rule__Rotacion__Group__5 : rule__Rotacion__Group__5__Impl rule__Rotacion__Group__6 ;
    public final void rule__Rotacion__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2052:1: ( rule__Rotacion__Group__5__Impl rule__Rotacion__Group__6 )
            // InternalTourDsl.g:2053:2: rule__Rotacion__Group__5__Impl rule__Rotacion__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Rotacion__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__5"


    // $ANTLR start "rule__Rotacion__Group__5__Impl"
    // InternalTourDsl.g:2060:1: rule__Rotacion__Group__5__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Rotacion__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2064:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2065:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2065:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2066:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_5()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__5__Impl"


    // $ANTLR start "rule__Rotacion__Group__6"
    // InternalTourDsl.g:2075:1: rule__Rotacion__Group__6 : rule__Rotacion__Group__6__Impl rule__Rotacion__Group__7 ;
    public final void rule__Rotacion__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2079:1: ( rule__Rotacion__Group__6__Impl rule__Rotacion__Group__7 )
            // InternalTourDsl.g:2080:2: rule__Rotacion__Group__6__Impl rule__Rotacion__Group__7
            {
            pushFollow(FOLLOW_20);
            rule__Rotacion__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__6"


    // $ANTLR start "rule__Rotacion__Group__6__Impl"
    // InternalTourDsl.g:2087:1: rule__Rotacion__Group__6__Impl : ( ( rule__Rotacion__XAssignment_6 )? ) ;
    public final void rule__Rotacion__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2091:1: ( ( ( rule__Rotacion__XAssignment_6 )? ) )
            // InternalTourDsl.g:2092:1: ( ( rule__Rotacion__XAssignment_6 )? )
            {
            // InternalTourDsl.g:2092:1: ( ( rule__Rotacion__XAssignment_6 )? )
            // InternalTourDsl.g:2093:2: ( rule__Rotacion__XAssignment_6 )?
            {
             before(grammarAccess.getRotacionAccess().getXAssignment_6()); 
            // InternalTourDsl.g:2094:2: ( rule__Rotacion__XAssignment_6 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_INT) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalTourDsl.g:2094:3: rule__Rotacion__XAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Rotacion__XAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRotacionAccess().getXAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__6__Impl"


    // $ANTLR start "rule__Rotacion__Group__7"
    // InternalTourDsl.g:2102:1: rule__Rotacion__Group__7 : rule__Rotacion__Group__7__Impl rule__Rotacion__Group__8 ;
    public final void rule__Rotacion__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2106:1: ( rule__Rotacion__Group__7__Impl rule__Rotacion__Group__8 )
            // InternalTourDsl.g:2107:2: rule__Rotacion__Group__7__Impl rule__Rotacion__Group__8
            {
            pushFollow(FOLLOW_21);
            rule__Rotacion__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__7"


    // $ANTLR start "rule__Rotacion__Group__7__Impl"
    // InternalTourDsl.g:2114:1: rule__Rotacion__Group__7__Impl : ( RULE_COMA ) ;
    public final void rule__Rotacion__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2118:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:2119:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:2119:1: ( RULE_COMA )
            // InternalTourDsl.g:2120:2: RULE_COMA
            {
             before(grammarAccess.getRotacionAccess().getCOMATerminalRuleCall_7()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getCOMATerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__7__Impl"


    // $ANTLR start "rule__Rotacion__Group__8"
    // InternalTourDsl.g:2129:1: rule__Rotacion__Group__8 : rule__Rotacion__Group__8__Impl rule__Rotacion__Group__9 ;
    public final void rule__Rotacion__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2133:1: ( rule__Rotacion__Group__8__Impl rule__Rotacion__Group__9 )
            // InternalTourDsl.g:2134:2: rule__Rotacion__Group__8__Impl rule__Rotacion__Group__9
            {
            pushFollow(FOLLOW_5);
            rule__Rotacion__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__8"


    // $ANTLR start "rule__Rotacion__Group__8__Impl"
    // InternalTourDsl.g:2141:1: rule__Rotacion__Group__8__Impl : ( RULE_ROTY ) ;
    public final void rule__Rotacion__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2145:1: ( ( RULE_ROTY ) )
            // InternalTourDsl.g:2146:1: ( RULE_ROTY )
            {
            // InternalTourDsl.g:2146:1: ( RULE_ROTY )
            // InternalTourDsl.g:2147:2: RULE_ROTY
            {
             before(grammarAccess.getRotacionAccess().getROTYTerminalRuleCall_8()); 
            match(input,RULE_ROTY,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getROTYTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__8__Impl"


    // $ANTLR start "rule__Rotacion__Group__9"
    // InternalTourDsl.g:2156:1: rule__Rotacion__Group__9 : rule__Rotacion__Group__9__Impl rule__Rotacion__Group__10 ;
    public final void rule__Rotacion__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2160:1: ( rule__Rotacion__Group__9__Impl rule__Rotacion__Group__10 )
            // InternalTourDsl.g:2161:2: rule__Rotacion__Group__9__Impl rule__Rotacion__Group__10
            {
            pushFollow(FOLLOW_20);
            rule__Rotacion__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__9"


    // $ANTLR start "rule__Rotacion__Group__9__Impl"
    // InternalTourDsl.g:2168:1: rule__Rotacion__Group__9__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Rotacion__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2172:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2173:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2173:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2174:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_9()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__9__Impl"


    // $ANTLR start "rule__Rotacion__Group__10"
    // InternalTourDsl.g:2183:1: rule__Rotacion__Group__10 : rule__Rotacion__Group__10__Impl rule__Rotacion__Group__11 ;
    public final void rule__Rotacion__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2187:1: ( rule__Rotacion__Group__10__Impl rule__Rotacion__Group__11 )
            // InternalTourDsl.g:2188:2: rule__Rotacion__Group__10__Impl rule__Rotacion__Group__11
            {
            pushFollow(FOLLOW_20);
            rule__Rotacion__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__10"


    // $ANTLR start "rule__Rotacion__Group__10__Impl"
    // InternalTourDsl.g:2195:1: rule__Rotacion__Group__10__Impl : ( ( rule__Rotacion__YAssignment_10 )? ) ;
    public final void rule__Rotacion__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2199:1: ( ( ( rule__Rotacion__YAssignment_10 )? ) )
            // InternalTourDsl.g:2200:1: ( ( rule__Rotacion__YAssignment_10 )? )
            {
            // InternalTourDsl.g:2200:1: ( ( rule__Rotacion__YAssignment_10 )? )
            // InternalTourDsl.g:2201:2: ( rule__Rotacion__YAssignment_10 )?
            {
             before(grammarAccess.getRotacionAccess().getYAssignment_10()); 
            // InternalTourDsl.g:2202:2: ( rule__Rotacion__YAssignment_10 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_INT) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalTourDsl.g:2202:3: rule__Rotacion__YAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__Rotacion__YAssignment_10();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRotacionAccess().getYAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__10__Impl"


    // $ANTLR start "rule__Rotacion__Group__11"
    // InternalTourDsl.g:2210:1: rule__Rotacion__Group__11 : rule__Rotacion__Group__11__Impl rule__Rotacion__Group__12 ;
    public final void rule__Rotacion__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2214:1: ( rule__Rotacion__Group__11__Impl rule__Rotacion__Group__12 )
            // InternalTourDsl.g:2215:2: rule__Rotacion__Group__11__Impl rule__Rotacion__Group__12
            {
            pushFollow(FOLLOW_22);
            rule__Rotacion__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__11"


    // $ANTLR start "rule__Rotacion__Group__11__Impl"
    // InternalTourDsl.g:2222:1: rule__Rotacion__Group__11__Impl : ( RULE_COMA ) ;
    public final void rule__Rotacion__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2226:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:2227:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:2227:1: ( RULE_COMA )
            // InternalTourDsl.g:2228:2: RULE_COMA
            {
             before(grammarAccess.getRotacionAccess().getCOMATerminalRuleCall_11()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getCOMATerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__11__Impl"


    // $ANTLR start "rule__Rotacion__Group__12"
    // InternalTourDsl.g:2237:1: rule__Rotacion__Group__12 : rule__Rotacion__Group__12__Impl rule__Rotacion__Group__13 ;
    public final void rule__Rotacion__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2241:1: ( rule__Rotacion__Group__12__Impl rule__Rotacion__Group__13 )
            // InternalTourDsl.g:2242:2: rule__Rotacion__Group__12__Impl rule__Rotacion__Group__13
            {
            pushFollow(FOLLOW_5);
            rule__Rotacion__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__12"


    // $ANTLR start "rule__Rotacion__Group__12__Impl"
    // InternalTourDsl.g:2249:1: rule__Rotacion__Group__12__Impl : ( RULE_ROTZ ) ;
    public final void rule__Rotacion__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2253:1: ( ( RULE_ROTZ ) )
            // InternalTourDsl.g:2254:1: ( RULE_ROTZ )
            {
            // InternalTourDsl.g:2254:1: ( RULE_ROTZ )
            // InternalTourDsl.g:2255:2: RULE_ROTZ
            {
             before(grammarAccess.getRotacionAccess().getROTZTerminalRuleCall_12()); 
            match(input,RULE_ROTZ,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getROTZTerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__12__Impl"


    // $ANTLR start "rule__Rotacion__Group__13"
    // InternalTourDsl.g:2264:1: rule__Rotacion__Group__13 : rule__Rotacion__Group__13__Impl rule__Rotacion__Group__14 ;
    public final void rule__Rotacion__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2268:1: ( rule__Rotacion__Group__13__Impl rule__Rotacion__Group__14 )
            // InternalTourDsl.g:2269:2: rule__Rotacion__Group__13__Impl rule__Rotacion__Group__14
            {
            pushFollow(FOLLOW_23);
            rule__Rotacion__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__13"


    // $ANTLR start "rule__Rotacion__Group__13__Impl"
    // InternalTourDsl.g:2276:1: rule__Rotacion__Group__13__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Rotacion__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2280:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2281:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2281:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2282:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_13()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getTWOPOINTSTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__13__Impl"


    // $ANTLR start "rule__Rotacion__Group__14"
    // InternalTourDsl.g:2291:1: rule__Rotacion__Group__14 : rule__Rotacion__Group__14__Impl rule__Rotacion__Group__15 ;
    public final void rule__Rotacion__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2295:1: ( rule__Rotacion__Group__14__Impl rule__Rotacion__Group__15 )
            // InternalTourDsl.g:2296:2: rule__Rotacion__Group__14__Impl rule__Rotacion__Group__15
            {
            pushFollow(FOLLOW_23);
            rule__Rotacion__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__14"


    // $ANTLR start "rule__Rotacion__Group__14__Impl"
    // InternalTourDsl.g:2303:1: rule__Rotacion__Group__14__Impl : ( ( rule__Rotacion__ZAssignment_14 )? ) ;
    public final void rule__Rotacion__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2307:1: ( ( ( rule__Rotacion__ZAssignment_14 )? ) )
            // InternalTourDsl.g:2308:1: ( ( rule__Rotacion__ZAssignment_14 )? )
            {
            // InternalTourDsl.g:2308:1: ( ( rule__Rotacion__ZAssignment_14 )? )
            // InternalTourDsl.g:2309:2: ( rule__Rotacion__ZAssignment_14 )?
            {
             before(grammarAccess.getRotacionAccess().getZAssignment_14()); 
            // InternalTourDsl.g:2310:2: ( rule__Rotacion__ZAssignment_14 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_INT) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalTourDsl.g:2310:3: rule__Rotacion__ZAssignment_14
                    {
                    pushFollow(FOLLOW_2);
                    rule__Rotacion__ZAssignment_14();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRotacionAccess().getZAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__14__Impl"


    // $ANTLR start "rule__Rotacion__Group__15"
    // InternalTourDsl.g:2318:1: rule__Rotacion__Group__15 : rule__Rotacion__Group__15__Impl ;
    public final void rule__Rotacion__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2322:1: ( rule__Rotacion__Group__15__Impl )
            // InternalTourDsl.g:2323:2: rule__Rotacion__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Rotacion__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__15"


    // $ANTLR start "rule__Rotacion__Group__15__Impl"
    // InternalTourDsl.g:2329:1: rule__Rotacion__Group__15__Impl : ( RULE_RBRACKET ) ;
    public final void rule__Rotacion__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2333:1: ( ( RULE_RBRACKET ) )
            // InternalTourDsl.g:2334:1: ( RULE_RBRACKET )
            {
            // InternalTourDsl.g:2334:1: ( RULE_RBRACKET )
            // InternalTourDsl.g:2335:2: RULE_RBRACKET
            {
             before(grammarAccess.getRotacionAccess().getRBRACKETTerminalRuleCall_15()); 
            match(input,RULE_RBRACKET,FOLLOW_2); 
             after(grammarAccess.getRotacionAccess().getRBRACKETTerminalRuleCall_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__Group__15__Impl"


    // $ANTLR start "rule__Posicion__Group__0"
    // InternalTourDsl.g:2345:1: rule__Posicion__Group__0 : rule__Posicion__Group__0__Impl rule__Posicion__Group__1 ;
    public final void rule__Posicion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2349:1: ( rule__Posicion__Group__0__Impl rule__Posicion__Group__1 )
            // InternalTourDsl.g:2350:2: rule__Posicion__Group__0__Impl rule__Posicion__Group__1
            {
            pushFollow(FOLLOW_18);
            rule__Posicion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__0"


    // $ANTLR start "rule__Posicion__Group__0__Impl"
    // InternalTourDsl.g:2357:1: rule__Posicion__Group__0__Impl : ( () ) ;
    public final void rule__Posicion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2361:1: ( ( () ) )
            // InternalTourDsl.g:2362:1: ( () )
            {
            // InternalTourDsl.g:2362:1: ( () )
            // InternalTourDsl.g:2363:2: ()
            {
             before(grammarAccess.getPosicionAccess().getPosicionAction_0()); 
            // InternalTourDsl.g:2364:2: ()
            // InternalTourDsl.g:2364:3: 
            {
            }

             after(grammarAccess.getPosicionAccess().getPosicionAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__0__Impl"


    // $ANTLR start "rule__Posicion__Group__1"
    // InternalTourDsl.g:2372:1: rule__Posicion__Group__1 : rule__Posicion__Group__1__Impl rule__Posicion__Group__2 ;
    public final void rule__Posicion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2376:1: ( rule__Posicion__Group__1__Impl rule__Posicion__Group__2 )
            // InternalTourDsl.g:2377:2: rule__Posicion__Group__1__Impl rule__Posicion__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Posicion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__1"


    // $ANTLR start "rule__Posicion__Group__1__Impl"
    // InternalTourDsl.g:2384:1: rule__Posicion__Group__1__Impl : ( RULE_POSITION ) ;
    public final void rule__Posicion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2388:1: ( ( RULE_POSITION ) )
            // InternalTourDsl.g:2389:1: ( RULE_POSITION )
            {
            // InternalTourDsl.g:2389:1: ( RULE_POSITION )
            // InternalTourDsl.g:2390:2: RULE_POSITION
            {
             before(grammarAccess.getPosicionAccess().getPOSITIONTerminalRuleCall_1()); 
            match(input,RULE_POSITION,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getPOSITIONTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__1__Impl"


    // $ANTLR start "rule__Posicion__Group__2"
    // InternalTourDsl.g:2399:1: rule__Posicion__Group__2 : rule__Posicion__Group__2__Impl rule__Posicion__Group__3 ;
    public final void rule__Posicion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2403:1: ( rule__Posicion__Group__2__Impl rule__Posicion__Group__3 )
            // InternalTourDsl.g:2404:2: rule__Posicion__Group__2__Impl rule__Posicion__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__Posicion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__2"


    // $ANTLR start "rule__Posicion__Group__2__Impl"
    // InternalTourDsl.g:2411:1: rule__Posicion__Group__2__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Posicion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2415:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2416:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2416:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2417:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_2()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__2__Impl"


    // $ANTLR start "rule__Posicion__Group__3"
    // InternalTourDsl.g:2426:1: rule__Posicion__Group__3 : rule__Posicion__Group__3__Impl rule__Posicion__Group__4 ;
    public final void rule__Posicion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2430:1: ( rule__Posicion__Group__3__Impl rule__Posicion__Group__4 )
            // InternalTourDsl.g:2431:2: rule__Posicion__Group__3__Impl rule__Posicion__Group__4
            {
            pushFollow(FOLLOW_24);
            rule__Posicion__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__3"


    // $ANTLR start "rule__Posicion__Group__3__Impl"
    // InternalTourDsl.g:2438:1: rule__Posicion__Group__3__Impl : ( RULE_LBRACKET ) ;
    public final void rule__Posicion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2442:1: ( ( RULE_LBRACKET ) )
            // InternalTourDsl.g:2443:1: ( RULE_LBRACKET )
            {
            // InternalTourDsl.g:2443:1: ( RULE_LBRACKET )
            // InternalTourDsl.g:2444:2: RULE_LBRACKET
            {
             before(grammarAccess.getPosicionAccess().getLBRACKETTerminalRuleCall_3()); 
            match(input,RULE_LBRACKET,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getLBRACKETTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__3__Impl"


    // $ANTLR start "rule__Posicion__Group__4"
    // InternalTourDsl.g:2453:1: rule__Posicion__Group__4 : rule__Posicion__Group__4__Impl rule__Posicion__Group__5 ;
    public final void rule__Posicion__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2457:1: ( rule__Posicion__Group__4__Impl rule__Posicion__Group__5 )
            // InternalTourDsl.g:2458:2: rule__Posicion__Group__4__Impl rule__Posicion__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Posicion__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__4"


    // $ANTLR start "rule__Posicion__Group__4__Impl"
    // InternalTourDsl.g:2465:1: rule__Posicion__Group__4__Impl : ( RULE_POSX ) ;
    public final void rule__Posicion__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2469:1: ( ( RULE_POSX ) )
            // InternalTourDsl.g:2470:1: ( RULE_POSX )
            {
            // InternalTourDsl.g:2470:1: ( RULE_POSX )
            // InternalTourDsl.g:2471:2: RULE_POSX
            {
             before(grammarAccess.getPosicionAccess().getPOSXTerminalRuleCall_4()); 
            match(input,RULE_POSX,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getPOSXTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__4__Impl"


    // $ANTLR start "rule__Posicion__Group__5"
    // InternalTourDsl.g:2480:1: rule__Posicion__Group__5 : rule__Posicion__Group__5__Impl rule__Posicion__Group__6 ;
    public final void rule__Posicion__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2484:1: ( rule__Posicion__Group__5__Impl rule__Posicion__Group__6 )
            // InternalTourDsl.g:2485:2: rule__Posicion__Group__5__Impl rule__Posicion__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Posicion__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__5"


    // $ANTLR start "rule__Posicion__Group__5__Impl"
    // InternalTourDsl.g:2492:1: rule__Posicion__Group__5__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Posicion__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2496:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2497:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2497:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2498:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_5()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__5__Impl"


    // $ANTLR start "rule__Posicion__Group__6"
    // InternalTourDsl.g:2507:1: rule__Posicion__Group__6 : rule__Posicion__Group__6__Impl rule__Posicion__Group__7 ;
    public final void rule__Posicion__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2511:1: ( rule__Posicion__Group__6__Impl rule__Posicion__Group__7 )
            // InternalTourDsl.g:2512:2: rule__Posicion__Group__6__Impl rule__Posicion__Group__7
            {
            pushFollow(FOLLOW_20);
            rule__Posicion__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__6"


    // $ANTLR start "rule__Posicion__Group__6__Impl"
    // InternalTourDsl.g:2519:1: rule__Posicion__Group__6__Impl : ( ( rule__Posicion__XAssignment_6 )? ) ;
    public final void rule__Posicion__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2523:1: ( ( ( rule__Posicion__XAssignment_6 )? ) )
            // InternalTourDsl.g:2524:1: ( ( rule__Posicion__XAssignment_6 )? )
            {
            // InternalTourDsl.g:2524:1: ( ( rule__Posicion__XAssignment_6 )? )
            // InternalTourDsl.g:2525:2: ( rule__Posicion__XAssignment_6 )?
            {
             before(grammarAccess.getPosicionAccess().getXAssignment_6()); 
            // InternalTourDsl.g:2526:2: ( rule__Posicion__XAssignment_6 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_INT) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalTourDsl.g:2526:3: rule__Posicion__XAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Posicion__XAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPosicionAccess().getXAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__6__Impl"


    // $ANTLR start "rule__Posicion__Group__7"
    // InternalTourDsl.g:2534:1: rule__Posicion__Group__7 : rule__Posicion__Group__7__Impl rule__Posicion__Group__8 ;
    public final void rule__Posicion__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2538:1: ( rule__Posicion__Group__7__Impl rule__Posicion__Group__8 )
            // InternalTourDsl.g:2539:2: rule__Posicion__Group__7__Impl rule__Posicion__Group__8
            {
            pushFollow(FOLLOW_25);
            rule__Posicion__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__7"


    // $ANTLR start "rule__Posicion__Group__7__Impl"
    // InternalTourDsl.g:2546:1: rule__Posicion__Group__7__Impl : ( RULE_COMA ) ;
    public final void rule__Posicion__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2550:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:2551:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:2551:1: ( RULE_COMA )
            // InternalTourDsl.g:2552:2: RULE_COMA
            {
             before(grammarAccess.getPosicionAccess().getCOMATerminalRuleCall_7()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getCOMATerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__7__Impl"


    // $ANTLR start "rule__Posicion__Group__8"
    // InternalTourDsl.g:2561:1: rule__Posicion__Group__8 : rule__Posicion__Group__8__Impl rule__Posicion__Group__9 ;
    public final void rule__Posicion__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2565:1: ( rule__Posicion__Group__8__Impl rule__Posicion__Group__9 )
            // InternalTourDsl.g:2566:2: rule__Posicion__Group__8__Impl rule__Posicion__Group__9
            {
            pushFollow(FOLLOW_5);
            rule__Posicion__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__8"


    // $ANTLR start "rule__Posicion__Group__8__Impl"
    // InternalTourDsl.g:2573:1: rule__Posicion__Group__8__Impl : ( RULE_POSY ) ;
    public final void rule__Posicion__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2577:1: ( ( RULE_POSY ) )
            // InternalTourDsl.g:2578:1: ( RULE_POSY )
            {
            // InternalTourDsl.g:2578:1: ( RULE_POSY )
            // InternalTourDsl.g:2579:2: RULE_POSY
            {
             before(grammarAccess.getPosicionAccess().getPOSYTerminalRuleCall_8()); 
            match(input,RULE_POSY,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getPOSYTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__8__Impl"


    // $ANTLR start "rule__Posicion__Group__9"
    // InternalTourDsl.g:2588:1: rule__Posicion__Group__9 : rule__Posicion__Group__9__Impl rule__Posicion__Group__10 ;
    public final void rule__Posicion__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2592:1: ( rule__Posicion__Group__9__Impl rule__Posicion__Group__10 )
            // InternalTourDsl.g:2593:2: rule__Posicion__Group__9__Impl rule__Posicion__Group__10
            {
            pushFollow(FOLLOW_20);
            rule__Posicion__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__9"


    // $ANTLR start "rule__Posicion__Group__9__Impl"
    // InternalTourDsl.g:2600:1: rule__Posicion__Group__9__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Posicion__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2604:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2605:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2605:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2606:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_9()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__9__Impl"


    // $ANTLR start "rule__Posicion__Group__10"
    // InternalTourDsl.g:2615:1: rule__Posicion__Group__10 : rule__Posicion__Group__10__Impl rule__Posicion__Group__11 ;
    public final void rule__Posicion__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2619:1: ( rule__Posicion__Group__10__Impl rule__Posicion__Group__11 )
            // InternalTourDsl.g:2620:2: rule__Posicion__Group__10__Impl rule__Posicion__Group__11
            {
            pushFollow(FOLLOW_20);
            rule__Posicion__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__10"


    // $ANTLR start "rule__Posicion__Group__10__Impl"
    // InternalTourDsl.g:2627:1: rule__Posicion__Group__10__Impl : ( ( rule__Posicion__YAssignment_10 )? ) ;
    public final void rule__Posicion__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2631:1: ( ( ( rule__Posicion__YAssignment_10 )? ) )
            // InternalTourDsl.g:2632:1: ( ( rule__Posicion__YAssignment_10 )? )
            {
            // InternalTourDsl.g:2632:1: ( ( rule__Posicion__YAssignment_10 )? )
            // InternalTourDsl.g:2633:2: ( rule__Posicion__YAssignment_10 )?
            {
             before(grammarAccess.getPosicionAccess().getYAssignment_10()); 
            // InternalTourDsl.g:2634:2: ( rule__Posicion__YAssignment_10 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_INT) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalTourDsl.g:2634:3: rule__Posicion__YAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__Posicion__YAssignment_10();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPosicionAccess().getYAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__10__Impl"


    // $ANTLR start "rule__Posicion__Group__11"
    // InternalTourDsl.g:2642:1: rule__Posicion__Group__11 : rule__Posicion__Group__11__Impl rule__Posicion__Group__12 ;
    public final void rule__Posicion__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2646:1: ( rule__Posicion__Group__11__Impl rule__Posicion__Group__12 )
            // InternalTourDsl.g:2647:2: rule__Posicion__Group__11__Impl rule__Posicion__Group__12
            {
            pushFollow(FOLLOW_26);
            rule__Posicion__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__11"


    // $ANTLR start "rule__Posicion__Group__11__Impl"
    // InternalTourDsl.g:2654:1: rule__Posicion__Group__11__Impl : ( RULE_COMA ) ;
    public final void rule__Posicion__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2658:1: ( ( RULE_COMA ) )
            // InternalTourDsl.g:2659:1: ( RULE_COMA )
            {
            // InternalTourDsl.g:2659:1: ( RULE_COMA )
            // InternalTourDsl.g:2660:2: RULE_COMA
            {
             before(grammarAccess.getPosicionAccess().getCOMATerminalRuleCall_11()); 
            match(input,RULE_COMA,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getCOMATerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__11__Impl"


    // $ANTLR start "rule__Posicion__Group__12"
    // InternalTourDsl.g:2669:1: rule__Posicion__Group__12 : rule__Posicion__Group__12__Impl rule__Posicion__Group__13 ;
    public final void rule__Posicion__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2673:1: ( rule__Posicion__Group__12__Impl rule__Posicion__Group__13 )
            // InternalTourDsl.g:2674:2: rule__Posicion__Group__12__Impl rule__Posicion__Group__13
            {
            pushFollow(FOLLOW_5);
            rule__Posicion__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__12"


    // $ANTLR start "rule__Posicion__Group__12__Impl"
    // InternalTourDsl.g:2681:1: rule__Posicion__Group__12__Impl : ( RULE_POSZ ) ;
    public final void rule__Posicion__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2685:1: ( ( RULE_POSZ ) )
            // InternalTourDsl.g:2686:1: ( RULE_POSZ )
            {
            // InternalTourDsl.g:2686:1: ( RULE_POSZ )
            // InternalTourDsl.g:2687:2: RULE_POSZ
            {
             before(grammarAccess.getPosicionAccess().getPOSZTerminalRuleCall_12()); 
            match(input,RULE_POSZ,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getPOSZTerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__12__Impl"


    // $ANTLR start "rule__Posicion__Group__13"
    // InternalTourDsl.g:2696:1: rule__Posicion__Group__13 : rule__Posicion__Group__13__Impl rule__Posicion__Group__14 ;
    public final void rule__Posicion__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2700:1: ( rule__Posicion__Group__13__Impl rule__Posicion__Group__14 )
            // InternalTourDsl.g:2701:2: rule__Posicion__Group__13__Impl rule__Posicion__Group__14
            {
            pushFollow(FOLLOW_23);
            rule__Posicion__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__13"


    // $ANTLR start "rule__Posicion__Group__13__Impl"
    // InternalTourDsl.g:2708:1: rule__Posicion__Group__13__Impl : ( RULE_TWOPOINTS ) ;
    public final void rule__Posicion__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2712:1: ( ( RULE_TWOPOINTS ) )
            // InternalTourDsl.g:2713:1: ( RULE_TWOPOINTS )
            {
            // InternalTourDsl.g:2713:1: ( RULE_TWOPOINTS )
            // InternalTourDsl.g:2714:2: RULE_TWOPOINTS
            {
             before(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_13()); 
            match(input,RULE_TWOPOINTS,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getTWOPOINTSTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__13__Impl"


    // $ANTLR start "rule__Posicion__Group__14"
    // InternalTourDsl.g:2723:1: rule__Posicion__Group__14 : rule__Posicion__Group__14__Impl rule__Posicion__Group__15 ;
    public final void rule__Posicion__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2727:1: ( rule__Posicion__Group__14__Impl rule__Posicion__Group__15 )
            // InternalTourDsl.g:2728:2: rule__Posicion__Group__14__Impl rule__Posicion__Group__15
            {
            pushFollow(FOLLOW_23);
            rule__Posicion__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Posicion__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__14"


    // $ANTLR start "rule__Posicion__Group__14__Impl"
    // InternalTourDsl.g:2735:1: rule__Posicion__Group__14__Impl : ( ( rule__Posicion__ZAssignment_14 )? ) ;
    public final void rule__Posicion__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2739:1: ( ( ( rule__Posicion__ZAssignment_14 )? ) )
            // InternalTourDsl.g:2740:1: ( ( rule__Posicion__ZAssignment_14 )? )
            {
            // InternalTourDsl.g:2740:1: ( ( rule__Posicion__ZAssignment_14 )? )
            // InternalTourDsl.g:2741:2: ( rule__Posicion__ZAssignment_14 )?
            {
             before(grammarAccess.getPosicionAccess().getZAssignment_14()); 
            // InternalTourDsl.g:2742:2: ( rule__Posicion__ZAssignment_14 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==RULE_INT) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalTourDsl.g:2742:3: rule__Posicion__ZAssignment_14
                    {
                    pushFollow(FOLLOW_2);
                    rule__Posicion__ZAssignment_14();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPosicionAccess().getZAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__14__Impl"


    // $ANTLR start "rule__Posicion__Group__15"
    // InternalTourDsl.g:2750:1: rule__Posicion__Group__15 : rule__Posicion__Group__15__Impl ;
    public final void rule__Posicion__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2754:1: ( rule__Posicion__Group__15__Impl )
            // InternalTourDsl.g:2755:2: rule__Posicion__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Posicion__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__15"


    // $ANTLR start "rule__Posicion__Group__15__Impl"
    // InternalTourDsl.g:2761:1: rule__Posicion__Group__15__Impl : ( RULE_RBRACKET ) ;
    public final void rule__Posicion__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2765:1: ( ( RULE_RBRACKET ) )
            // InternalTourDsl.g:2766:1: ( RULE_RBRACKET )
            {
            // InternalTourDsl.g:2766:1: ( RULE_RBRACKET )
            // InternalTourDsl.g:2767:2: RULE_RBRACKET
            {
             before(grammarAccess.getPosicionAccess().getRBRACKETTerminalRuleCall_15()); 
            match(input,RULE_RBRACKET,FOLLOW_2); 
             after(grammarAccess.getPosicionAccess().getRBRACKETTerminalRuleCall_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__Group__15__Impl"


    // $ANTLR start "rule__Tour__NombreAssignment_4"
    // InternalTourDsl.g:2777:1: rule__Tour__NombreAssignment_4 : ( ruleEString ) ;
    public final void rule__Tour__NombreAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2781:1: ( ( ruleEString ) )
            // InternalTourDsl.g:2782:2: ( ruleEString )
            {
            // InternalTourDsl.g:2782:2: ( ruleEString )
            // InternalTourDsl.g:2783:3: ruleEString
            {
             before(grammarAccess.getTourAccess().getNombreEStringParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTourAccess().getNombreEStringParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__NombreAssignment_4"


    // $ANTLR start "rule__Tour__PanoramaAssignment_9"
    // InternalTourDsl.g:2792:1: rule__Tour__PanoramaAssignment_9 : ( rulePanorama ) ;
    public final void rule__Tour__PanoramaAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2796:1: ( ( rulePanorama ) )
            // InternalTourDsl.g:2797:2: ( rulePanorama )
            {
            // InternalTourDsl.g:2797:2: ( rulePanorama )
            // InternalTourDsl.g:2798:3: rulePanorama
            {
             before(grammarAccess.getTourAccess().getPanoramaPanoramaParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            rulePanorama();

            state._fsp--;

             after(grammarAccess.getTourAccess().getPanoramaPanoramaParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Tour__PanoramaAssignment_9"


    // $ANTLR start "rule__Panorama__NombreAssignment_4"
    // InternalTourDsl.g:2807:1: rule__Panorama__NombreAssignment_4 : ( ruleEString ) ;
    public final void rule__Panorama__NombreAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2811:1: ( ( ruleEString ) )
            // InternalTourDsl.g:2812:2: ( ruleEString )
            {
            // InternalTourDsl.g:2812:2: ( ruleEString )
            // InternalTourDsl.g:2813:3: ruleEString
            {
             before(grammarAccess.getPanoramaAccess().getNombreEStringParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getPanoramaAccess().getNombreEStringParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__NombreAssignment_4"


    // $ANTLR start "rule__Panorama__NombreAssignment_8"
    // InternalTourDsl.g:2822:1: rule__Panorama__NombreAssignment_8 : ( RULE_STRING ) ;
    public final void rule__Panorama__NombreAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2826:1: ( ( RULE_STRING ) )
            // InternalTourDsl.g:2827:2: ( RULE_STRING )
            {
            // InternalTourDsl.g:2827:2: ( RULE_STRING )
            // InternalTourDsl.g:2828:3: RULE_STRING
            {
             before(grammarAccess.getPanoramaAccess().getNombreSTRINGTerminalRuleCall_8_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPanoramaAccess().getNombreSTRINGTerminalRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__NombreAssignment_8"


    // $ANTLR start "rule__Panorama__RotacionPanoramaAssignment_10"
    // InternalTourDsl.g:2837:1: rule__Panorama__RotacionPanoramaAssignment_10 : ( ruleRotacionPanorama ) ;
    public final void rule__Panorama__RotacionPanoramaAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2841:1: ( ( ruleRotacionPanorama ) )
            // InternalTourDsl.g:2842:2: ( ruleRotacionPanorama )
            {
            // InternalTourDsl.g:2842:2: ( ruleRotacionPanorama )
            // InternalTourDsl.g:2843:3: ruleRotacionPanorama
            {
             before(grammarAccess.getPanoramaAccess().getRotacionPanoramaRotacionPanoramaParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleRotacionPanorama();

            state._fsp--;

             after(grammarAccess.getPanoramaAccess().getRotacionPanoramaRotacionPanoramaParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__RotacionPanoramaAssignment_10"


    // $ANTLR start "rule__Panorama__HotspotAssignment_15"
    // InternalTourDsl.g:2852:1: rule__Panorama__HotspotAssignment_15 : ( ruleHotspot ) ;
    public final void rule__Panorama__HotspotAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2856:1: ( ( ruleHotspot ) )
            // InternalTourDsl.g:2857:2: ( ruleHotspot )
            {
            // InternalTourDsl.g:2857:2: ( ruleHotspot )
            // InternalTourDsl.g:2858:3: ruleHotspot
            {
             before(grammarAccess.getPanoramaAccess().getHotspotHotspotParserRuleCall_15_0()); 
            pushFollow(FOLLOW_2);
            ruleHotspot();

            state._fsp--;

             after(grammarAccess.getPanoramaAccess().getHotspotHotspotParserRuleCall_15_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Panorama__HotspotAssignment_15"


    // $ANTLR start "rule__Hotspot__NombreAssignment_4"
    // InternalTourDsl.g:2867:1: rule__Hotspot__NombreAssignment_4 : ( ruleEString ) ;
    public final void rule__Hotspot__NombreAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2871:1: ( ( ruleEString ) )
            // InternalTourDsl.g:2872:2: ( ruleEString )
            {
            // InternalTourDsl.g:2872:2: ( ruleEString )
            // InternalTourDsl.g:2873:3: ruleEString
            {
             before(grammarAccess.getHotspotAccess().getNombreEStringParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getHotspotAccess().getNombreEStringParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__NombreAssignment_4"


    // $ANTLR start "rule__Hotspot__DirigeAssignment_8"
    // InternalTourDsl.g:2882:1: rule__Hotspot__DirigeAssignment_8 : ( ( RULE_STRING ) ) ;
    public final void rule__Hotspot__DirigeAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2886:1: ( ( ( RULE_STRING ) ) )
            // InternalTourDsl.g:2887:2: ( ( RULE_STRING ) )
            {
            // InternalTourDsl.g:2887:2: ( ( RULE_STRING ) )
            // InternalTourDsl.g:2888:3: ( RULE_STRING )
            {
             before(grammarAccess.getHotspotAccess().getDirigePanoramaCrossReference_8_0()); 
            // InternalTourDsl.g:2889:3: ( RULE_STRING )
            // InternalTourDsl.g:2890:4: RULE_STRING
            {
             before(grammarAccess.getHotspotAccess().getDirigePanoramaSTRINGTerminalRuleCall_8_0_1()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getHotspotAccess().getDirigePanoramaSTRINGTerminalRuleCall_8_0_1()); 

            }

             after(grammarAccess.getHotspotAccess().getDirigePanoramaCrossReference_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__DirigeAssignment_8"


    // $ANTLR start "rule__Hotspot__PosicionAssignment_10"
    // InternalTourDsl.g:2901:1: rule__Hotspot__PosicionAssignment_10 : ( rulePosicion ) ;
    public final void rule__Hotspot__PosicionAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2905:1: ( ( rulePosicion ) )
            // InternalTourDsl.g:2906:2: ( rulePosicion )
            {
            // InternalTourDsl.g:2906:2: ( rulePosicion )
            // InternalTourDsl.g:2907:3: rulePosicion
            {
             before(grammarAccess.getHotspotAccess().getPosicionPosicionParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            rulePosicion();

            state._fsp--;

             after(grammarAccess.getHotspotAccess().getPosicionPosicionParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__PosicionAssignment_10"


    // $ANTLR start "rule__Hotspot__RotacionAssignment_12"
    // InternalTourDsl.g:2916:1: rule__Hotspot__RotacionAssignment_12 : ( ruleRotacion ) ;
    public final void rule__Hotspot__RotacionAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2920:1: ( ( ruleRotacion ) )
            // InternalTourDsl.g:2921:2: ( ruleRotacion )
            {
            // InternalTourDsl.g:2921:2: ( ruleRotacion )
            // InternalTourDsl.g:2922:3: ruleRotacion
            {
             before(grammarAccess.getHotspotAccess().getRotacionRotacionParserRuleCall_12_0()); 
            pushFollow(FOLLOW_2);
            ruleRotacion();

            state._fsp--;

             after(grammarAccess.getHotspotAccess().getRotacionRotacionParserRuleCall_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Hotspot__RotacionAssignment_12"


    // $ANTLR start "rule__RotacionPanorama__XAssignment_6"
    // InternalTourDsl.g:2931:1: rule__RotacionPanorama__XAssignment_6 : ( ruleEInt ) ;
    public final void rule__RotacionPanorama__XAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2935:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:2936:2: ( ruleEInt )
            {
            // InternalTourDsl.g:2936:2: ( ruleEInt )
            // InternalTourDsl.g:2937:3: ruleEInt
            {
             before(grammarAccess.getRotacionPanoramaAccess().getXEIntParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getRotacionPanoramaAccess().getXEIntParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__XAssignment_6"


    // $ANTLR start "rule__RotacionPanorama__YAssignment_10"
    // InternalTourDsl.g:2946:1: rule__RotacionPanorama__YAssignment_10 : ( ruleEInt ) ;
    public final void rule__RotacionPanorama__YAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2950:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:2951:2: ( ruleEInt )
            {
            // InternalTourDsl.g:2951:2: ( ruleEInt )
            // InternalTourDsl.g:2952:3: ruleEInt
            {
             before(grammarAccess.getRotacionPanoramaAccess().getYEIntParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getRotacionPanoramaAccess().getYEIntParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__YAssignment_10"


    // $ANTLR start "rule__RotacionPanorama__ZAssignment_14"
    // InternalTourDsl.g:2961:1: rule__RotacionPanorama__ZAssignment_14 : ( ruleEInt ) ;
    public final void rule__RotacionPanorama__ZAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2965:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:2966:2: ( ruleEInt )
            {
            // InternalTourDsl.g:2966:2: ( ruleEInt )
            // InternalTourDsl.g:2967:3: ruleEInt
            {
             before(grammarAccess.getRotacionPanoramaAccess().getZEIntParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getRotacionPanoramaAccess().getZEIntParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RotacionPanorama__ZAssignment_14"


    // $ANTLR start "rule__Rotacion__XAssignment_6"
    // InternalTourDsl.g:2976:1: rule__Rotacion__XAssignment_6 : ( ruleEInt ) ;
    public final void rule__Rotacion__XAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2980:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:2981:2: ( ruleEInt )
            {
            // InternalTourDsl.g:2981:2: ( ruleEInt )
            // InternalTourDsl.g:2982:3: ruleEInt
            {
             before(grammarAccess.getRotacionAccess().getXEIntParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getRotacionAccess().getXEIntParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__XAssignment_6"


    // $ANTLR start "rule__Rotacion__YAssignment_10"
    // InternalTourDsl.g:2991:1: rule__Rotacion__YAssignment_10 : ( ruleEInt ) ;
    public final void rule__Rotacion__YAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:2995:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:2996:2: ( ruleEInt )
            {
            // InternalTourDsl.g:2996:2: ( ruleEInt )
            // InternalTourDsl.g:2997:3: ruleEInt
            {
             before(grammarAccess.getRotacionAccess().getYEIntParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getRotacionAccess().getYEIntParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__YAssignment_10"


    // $ANTLR start "rule__Rotacion__ZAssignment_14"
    // InternalTourDsl.g:3006:1: rule__Rotacion__ZAssignment_14 : ( ruleEInt ) ;
    public final void rule__Rotacion__ZAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:3010:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:3011:2: ( ruleEInt )
            {
            // InternalTourDsl.g:3011:2: ( ruleEInt )
            // InternalTourDsl.g:3012:3: ruleEInt
            {
             before(grammarAccess.getRotacionAccess().getZEIntParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getRotacionAccess().getZEIntParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rotacion__ZAssignment_14"


    // $ANTLR start "rule__Posicion__XAssignment_6"
    // InternalTourDsl.g:3021:1: rule__Posicion__XAssignment_6 : ( ruleEInt ) ;
    public final void rule__Posicion__XAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:3025:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:3026:2: ( ruleEInt )
            {
            // InternalTourDsl.g:3026:2: ( ruleEInt )
            // InternalTourDsl.g:3027:3: ruleEInt
            {
             before(grammarAccess.getPosicionAccess().getXEIntParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getPosicionAccess().getXEIntParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__XAssignment_6"


    // $ANTLR start "rule__Posicion__YAssignment_10"
    // InternalTourDsl.g:3036:1: rule__Posicion__YAssignment_10 : ( ruleEInt ) ;
    public final void rule__Posicion__YAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:3040:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:3041:2: ( ruleEInt )
            {
            // InternalTourDsl.g:3041:2: ( ruleEInt )
            // InternalTourDsl.g:3042:3: ruleEInt
            {
             before(grammarAccess.getPosicionAccess().getYEIntParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getPosicionAccess().getYEIntParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__YAssignment_10"


    // $ANTLR start "rule__Posicion__ZAssignment_14"
    // InternalTourDsl.g:3051:1: rule__Posicion__ZAssignment_14 : ( ruleEInt ) ;
    public final void rule__Posicion__ZAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTourDsl.g:3055:1: ( ( ruleEInt ) )
            // InternalTourDsl.g:3056:2: ( ruleEInt )
            {
            // InternalTourDsl.g:3056:2: ( ruleEInt )
            // InternalTourDsl.g:3057:3: ruleEInt
            {
             before(grammarAccess.getPosicionAccess().getZEIntParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getPosicionAccess().getZEIntParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Posicion__ZAssignment_14"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000042L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000001200L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000001000000L});

}